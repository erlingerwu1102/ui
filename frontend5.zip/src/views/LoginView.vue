<template>
  <div class="login-container">
    <div class="login-box">
      <div class="logo">
        <span class="logo-icon"></span>
        <h1>SwiftMate <span class="version">Pro</span></h1>
      </div>
      
      <div class="form-group">
        <label>ACCOUNT ID</label>
        <input 
          v-model="form.username" 
          type="text" 
          placeholder="SWIFTMATE or SWIFT01..."
          @keyup.enter="handleLogin"
        >
      </div>

      <div class="form-group">
        <label>PASSWORD</label>
        <input 
          v-model="form.password" 
          type="password" 
          placeholder="Enter password"
          @keyup.enter="handleLogin"
        >
      </div>

      <div class="error-msg" v-if="error">{{ error }}</div>

      <button class="login-btn" :class="{ loading }" @click="handleLogin">
        {{ loading ? 'VERIFYING...' : 'INITIALIZE SYSTEM' }}
      </button>

      <div class="login-footer">
        <p>Admin: SWIFTMATE / swiftmate</p>
        <p>User: SWIFT* (e.g. SWIFT01) / swift</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const form = ref({ username: '', password: '' })
const error = ref('')
const loading = ref(false)

const handleLogin = async () => {
  error.value = ''
  loading.value = true
  
  // 模拟网络延迟，增加真实感
  await new Promise(r => setTimeout(r, 800))

  const u = form.value.username.trim()
  const p = form.value.password.trim()

  // 1. 管理员登录逻辑
  if (u === 'SWIFTMATE' && p === 'swiftmate') {
    localStorage.setItem('user_role', 'admin')
    localStorage.setItem('user_name', u)
    router.push('/admin')
  } 
  // 2. 普通用户登录逻辑 (SWIFT 开头，密码 swift)
  else if (u.startsWith('SWIFT') && p === 'swift') {
    localStorage.setItem('user_role', 'user')
    localStorage.setItem('user_name', u)
    // 重置新手引导标志，确保每次新登录都能看到提示（或者改为只看一次）
    localStorage.removeItem('guide_completed') 
    router.push('/trajectory')
  } 
  else {
    error.value = 'Invalid Credentials / Access Denied'
  }
  
  loading.value = false
}
</script>

<style scoped>
.login-container { height: 100vh; background: #0f172a; display: flex; align-items: center; justify-content: center; font-family: 'Inter', sans-serif; }
.login-box { width: 360px; background: #1e293b; padding: 40px; border-radius: 12px; border: 1px solid #334155; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3); }
.logo { text-align: center; margin-bottom: 30px; color: #fff; }
.logo h1 { font-size: 24px; font-weight: 800; letter-spacing: -1px; margin: 0; display: inline-block; }
.version { font-size: 10px; background: #3b82f6; padding: 2px 6px; border-radius: 4px; vertical-align: top; margin-left: 4px; }
.logo-icon { font-size: 28px; margin-right: 8px; vertical-align: middle; }
.form-group { margin-bottom: 20px; }
.form-group label { display: block; font-size: 10px; color: #94a3b8; font-weight: 700; margin-bottom: 6px; letter-spacing: 1px; }
.form-group input { width: 100%; background: #0f172a; border: 1px solid #334155; padding: 10px; border-radius: 6px; color: #fff; font-family: monospace; font-size: 14px; outline: none; transition: border 0.2s; }
.form-group input:focus { border-color: #3b82f6; }
.login-btn { width: 100%; background: #3b82f6; color: #fff; border: none; padding: 12px; border-radius: 6px; font-weight: 700; font-size: 12px; letter-spacing: 1px; cursor: pointer; transition: background 0.2s; }
.login-btn:hover { background: #2563eb; }
.login-btn.loading { opacity: 0.7; cursor: wait; }
.error-msg { color: #ef4444; font-size: 12px; text-align: center; margin-bottom: 15px; font-weight: 600; }
.login-footer { margin-top: 30px; border-top: 1px solid #334155; padding-top: 15px; font-size: 10px; color: #64748b; text-align: center; font-family: monospace; }
</style>