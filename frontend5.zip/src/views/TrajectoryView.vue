<template>
  <MainLayout class="app-container">
    <template #left>
      <div class="col-left">
        <div class="panel-dark camera-panel h-[200px] flex flex-col bg-[#0f172a] border border-[#334155] rounded-lg overflow-hidden text-white">
          <div class="header p-2 bg-[#1e293b] flex justify-between items-center text-[11px] font-extrabold text-gray-400 border-b border-[#334155]">
            <span>📹 CAMERA FEED</span>
            <span :class="status === 'running' ? 'text-red-500 animate-pulse' : 'text-gray-400'">{{ status === 'running' ? '● REC' : 'STANDBY' }}</span>
          </div>
          <div class="relative flex-1 bg-black">
            <CameraView /> <div class="absolute inset-0 p-2 flex flex-col justify-between pointer-events-none text-[10px] font-mono text-white/70">
              <div class="flex justify-between"><span>RAW 4K</span><span>24 FPS</span></div>
              <div class="flex justify-between"><span>ISO 800</span><span>180°</span></div>
            </div>
          </div>
        </div>

        <WaypointList 
          :points="points" 
          :selectedIndex="selectedIndex"
          @select="idx => selectedIndex = idx"
          @remove="removePoint"
          @add="addPoint"
          @update="/* handled by v-model inside */"
          @save-template="saveTemplate"
        />

        <div class="panel-light h-[150px] bg-white border border-gray-200 rounded-lg p-2 overflow-y-auto">
          <h3 class="text-xs font-bold text-gray-500 mb-2">📚 SHOT TEMPLATES</h3>
          <div class="grid grid-cols-2 gap-2">
            <button v-for="t in templates" :key="t.name" class="p-2 border rounded text-left hover:border-blue-500" @click="loadTemplate(t)">
              <div class="text-lg">{{ t.icon }}</div>
              <div class="text-[10px] font-bold text-gray-700">{{ t.name }}</div>
            </button>
          </div>
        </div>
      </div>
    </template>

    <template #center>
      <div class="col-center h-full bg-black rounded-lg border border-[#334155] overflow-hidden relative">
        <Viewport3D 
          v-model:points="points"
          v-model:drawMode="drawMode"
          :selectedIndex="selectedIndex"
          :joints="joints"
          @select-point="idx => selectedIndex = idx"
        />

        <div class="absolute bottom-3 left-3 right-3 bg-[#1e293b]/90 p-2 rounded flex items-center gap-3 border border-[#334155]">
          <button class="w-8 h-8 bg-red-500 text-white rounded font-bold flex items-center justify-center" @click="togglePlay">
            {{ isPlaying ? '⏸' : '▶' }}
          </button>
          <div class="flex-1 h-1 bg-gray-700 rounded overflow-hidden">
            <div class="h-full bg-red-500 transition-all duration-75" :style="{width: progress + '%'}"></div>
          </div>
          <span class="text-[10px] font-mono text-gray-400 w-8 text-right">{{ progress.toFixed(0) }}%</span>
        </div>
      </div>
    </template>

    <template #right>
      <div class="col-right flex flex-col h-full bg-black">
        <div class="flex border-b border-[#334155] bg-black">
          <button 
            v-for="tab in ['OPERATION', 'SYSTEM']" :key="tab"
            class="flex-1 p-3 text-[11px] font-bold text-gray-500 hover:text-white transition-colors border-b-2"
            :class="activeTab === tab ? 'border-blue-500 text-white bg-[#1e293b]' : 'border-transparent'"
            @click="activeTab = tab"
          >
            {{ tab }}
          </button>
        </div>

        <div v-if="activeTab === 'OPERATION'" class="flex-1 p-3 flex flex-col gap-4 overflow-y-auto bg-[#0f172a]">
          <div class="bg-[#1e293b] p-3 rounded border border-[#334155]">
            <div class="text-[10px] font-bold text-gray-500 mb-2">⚙️ MOTION CONTROL</div>
            <div class="space-y-3">
              <div>
                <label class="text-[10px] text-gray-400 block mb-1">SPEED</label>
                <div class="flex gap-2">
                  <input type="range" v-model.number="params.speed" class="flex-1 accent-blue-500">
                  <span class="text-[11px] font-mono text-blue-400 w-8 text-right">{{ params.speed }}</span>
                </div>
              </div>
              <div>
                <label class="text-[10px] text-gray-400 block mb-1">ACCEL</label>
                <div class="flex gap-2">
                  <input type="range" v-model.number="params.accel" class="flex-1 accent-blue-500">
                  <span class="text-[11px] font-mono text-blue-400 w-8 text-right">{{ params.accel }}</span>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-[#1e293b] p-3 rounded border border-[#334155] flex-1">
            <div class="text-[10px] font-bold text-gray-500 mb-2">📊 TELEMETRY</div>
            <div class="space-y-2 font-mono text-xs">
              <div class="flex justify-between items-center border-b border-gray-700 pb-1">
                <span class="text-gray-400">J1 (Base)</span>
                <span class="text-white">{{ joints[0].toFixed(1) }}°</span>
              </div>
              <div class="flex justify-between items-center border-b border-gray-700 pb-1">
                <span class="text-gray-400">J2 (Shoulder)</span>
                <span class="text-white">{{ joints[1].toFixed(1) }}°</span>
              </div>
              <div class="flex justify-between items-center border-b border-gray-700 pb-1">
                <span class="text-gray-400">J3 (Elbow)</span>
                <span class="text-white">{{ joints[2].toFixed(1) }}°</span>
              </div>
              </div>
          </div>

          <button class="w-full py-4 bg-red-600 text-white font-black rounded hover:bg-red-700 transition-colors" @click="estop">
            EMERGENCY STOP
          </button>
        </div>

        <div v-else class="flex-1 bg-black p-2 font-mono text-[11px] text-gray-400 overflow-y-auto">
          <div v-for="(log, i) in logs" :key="i" class="mb-1">
            <span class="text-gray-600">[{{ log.time }}]</span>
            <span :class="log.type === 'error' ? 'text-red-500' : 'text-blue-400'"> {{ log.msg }}</span>
          </div>
        </div>
      </div>
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import MainLayout from '@/layouts/MainLayout.vue'
import CameraView from '@/components/viewport/CameraView.vue'
import Viewport3D from '@/components/trajectory/Viewport3D.vue'
import WaypointList from '@/components/trajectory/WaypointList.vue'
import { shotApi } from '@/api/shot'

// --- State ---
const status = ref('ready')
const activeTab = ref('OPERATION')
const drawMode = ref('select')
const selectedIndex = ref(0)
const isPlaying = ref(false)
const progress = ref(0)

const points = ref([
  { x: 300, y: 0, z: 200, type: 'LIN', speed: 50, accel: 30, id: '1' },
  { x: 500, y: 300, z: 400, type: 'SPLINE', speed: 80, accel: 50, id: '2' },
])
const params = reactive({ speed: 50, accel: 50 })
const joints = ref([0, 0, 0, 0, 0, 0])
const logs = ref<any[]>([])

const templates = [
  { name: 'One Take', icon: '🎬', points: [] },
  { name: 'Orbit', icon: '🪐', points: [] }
]

// --- Methods ---
const addPoint = () => {
  const last = points.value[points.value.length - 1]
  points.value.push({ ...last, x: last.x + 50, id: Date.now().toString() })
}
const removePoint = (i: number) => {
  points.value.splice(i, 1)
  selectedIndex.value = -1
}
const saveTemplate = () => alert('Saved')
const loadTemplate = (t: any) => console.log('Load', t)
const estop = () => {
  status.value = 'error'
  isPlaying.value = false
  logs.value.push({ time: new Date().toLocaleTimeString(), type: 'error', msg: 'E-STOP TRIGGERED' })
}

const togglePlay = () => {
  isPlaying.value = !isPlaying.value
  status.value = isPlaying.value ? 'running' : 'ready'
  if (isPlaying.value) {
    // 模拟播放时关节运动
    const interval = setInterval(() => {
      if (!isPlaying.value) clearInterval(interval)
      progress.value = (progress.value + 1) % 100
      // 简单模拟关节正弦运动
      joints.value = joints.value.map((j, idx) => Math.sin(Date.now() / 1000 + idx) * 30)
    }, 50)
  }
}

// 轮询真实数据
onMounted(() => {
  setInterval(async () => {
    if (!isPlaying.value) {
      try {
        const res = await shotApi.getStatus()
        if (res.data.code === 200 && res.data.data.joints) {
          joints.value = res.data.data.joints
        }
      } catch (e) {}
    }
  }, 200)
  logs.value.push({ time: new Date().toLocaleTimeString(), type: 'info', msg: 'System Ready' })
})
</script>

<style scoped>
/* 简单补充 Layout 样式 */
.col-left, .col-center, .col-right { display: flex; flex-direction: column; gap: 12px; height: 100%; overflow: hidden; }
</style>