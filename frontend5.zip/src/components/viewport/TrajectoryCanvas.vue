<template>
  <MainLayout class="app-container">
    <template #left>
      <div class="col-left">
        <div class="panel-dark camera-box">
          <div class="panel-header-dark">
            <span>📹 CAMERA FEED</span>
            <span :class="status === 'running' ? 'status-rec' : 'status-idle'">
              {{ status === 'running' ? '● REC' : 'STANDBY' }}
            </span>
          </div>
          <div class="camera-content">
            <CameraView /> <div class="hud-overlay">
              <div class="hud-row"><span>4K 60FPS</span><span>ISO 800</span></div>
              <div class="crosshair"></div>
            </div>
          </div>
        </div>

        <WaypointList 
          :points="points" 
          :selectedIndex="selectedIndex"
          @select="selectPoint"
          @update="updatePoint"
          @add="addPoint"
          @remove="removePoint"
          @save="saveTemplate"
        />

        <div class="panel-light template-box custom-scroll-light">
          <div class="panel-header-light"><h3>📚 SHOT TEMPLATES</h3></div>
          <div class="tpl-grid">
            <button v-for="t in templates" :key="t.name" class="tpl-item" @click="loadTemplate(t)">
              <span class="tpl-icon">{{ t.icon }}</span>
              <span class="tpl-name">{{ t.name }}</span>
            </button>
          </div>
        </div>
      </div>
    </template>

    <template #center>
      <div class="col-center">
        <Viewport3D 
          :points="points"
          :selectedIndex="selectedIndex"
          :joints="joints"
          :status="status"
          @update:points="syncPoints"
          @select="selectPoint"
        />
      </div>
    </template>

    <template #right>
      <div class="col-right">
        <div class="tabs-header">
          <button 
            class="tab-btn" 
            :class="{ active: activeTab === 'operation' }" 
            @click="activeTab = 'operation'"
          >
            OPERATION
          </button>
          <button 
            class="tab-btn" 
            :class="{ active: activeTab === 'system' }" 
            @click="activeTab = 'system'"
          >
            SYSTEM LOGS
          </button>
        </div>

        <div v-show="activeTab === 'operation'" class="tab-content bg-dark">
          <MotionPanel 
            v-model:speed="params.speed"
            v-model:accel="params.accel"
            v-model:precision="params.precision"
            :selectedIndex="selectedIndex"
            @estop="triggerEstop"
          />
          <div class="spacer"></div>
          <TelemetryPanel 
            :robotPos="robotPos" 
            :joints="joints" 
          />
        </div>

        <div v-show="activeTab === 'system'" class="tab-content bg-light">
          <SystemLogPanel :logs="logs" />
        </div>
      </div>
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import MainLayout from '@/layouts/MainLayout.vue'
import CameraView from '@/components/viewport/CameraView.vue'
import Viewport3D from '@/components/trajectory/Viewport3D.vue'
import WaypointList from '@/components/trajectory/WaypointList.vue'
import MotionPanel from '@/components/trajectory/MotionPanel.vue'
import TelemetryPanel from '@/components/trajectory/TelemetryPanel.vue'
import SystemLogPanel from '@/components/trajectory/SystemLogPanel.vue'
import { shotApi } from '@/api/shot'

// --- State ---
const activeTab = ref<'operation' | 'system'>('operation')
const status = ref('ready')
const selectedIndex = ref(-1)
const points = ref<any[]>([
  { x: 400, y: 0, z: 300, type: 'LIN', id: '1' },
  { x: 600, y: 200, z: 400, type: 'SPLINE', id: '2' }
])
const params = reactive({ speed: 50, accel: 50, precision: 'SPLINE' })
const joints = ref([0, 0, 0, 0, 0, 0])
const robotPos = ref({ x: 0, y: 0, z: 0 })
const logs = ref<any[]>([])
const templates = [
  { name: 'One Take', icon: '🎬', points: [] },
  { name: 'Orbit', icon: '🪐', points: [] }
]

// --- Logic ---
const selectPoint = (idx: number) => selectedIndex.value = idx
const updatePoint = () => { /* 触发 3D 更新 */ }
const syncPoints = (newPoints: any[]) => points.value = newPoints
const addPoint = () => {
  const last = points.value[points.value.length-1] || {x:300, y:0, z:300}
  points.value.push({ ...last, x: last.x + 50, id: Date.now().toString(), type: 'LIN' })
}
const removePoint = (i: number) => {
  points.value.splice(i, 1)
  selectedIndex.value = -1
}
const saveTemplate = () => alert('Template Saved')
const loadTemplate = (t: any) => console.log('Load', t)
const triggerEstop = () => {
  status.value = 'error'
  logs.value.push({ time: new Date().toLocaleTimeString(), type: 'error', msg: 'EMERGENCY STOP TRIGGERED' })
}

// 模拟数据流
onMounted(() => {
  logs.value.push({ time: new Date().toLocaleTimeString(), type: 'info', msg: 'System initialized' })
  setInterval(async () => {
    try {
      const res = await shotApi.getStatus()
      if (res.data.code === 200) {
        if(res.data.data.joints) joints.value = res.data.data.joints
        if(res.data.data.current_pos) {
          const [x,y,z] = res.data.data.current_pos
          robotPos.value = { x: x*1000, y: y*1000, z: z*1000 } // m -> mm
        }
      }
    } catch {}
  }, 200)
})
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+SC:wght@400;500;700&display=swap');

.app-container {
  font-family: 'Noto Sans SC', 'Inter', sans-serif; /* 思源黑体风格 */
  background: #f1f5f9;
  color: #1e293b;
}

.col-left { display: flex; flex-direction: column; gap: 12px; height: 100%; overflow: hidden; }
.col-center { height: 100%; overflow: hidden; border-radius: 8px; border: 1px solid #334155; }
.col-right { display: flex; flex-direction: column; height: 100%; overflow: hidden; border-left: 1px solid #e2e8f0; }

/* Panels */
.panel-dark { background: #0f172a; color: #fff; border-radius: 8px; overflow: hidden; border: 1px solid #334155; }
.panel-light { background: #fff; color: #1e293b; border-radius: 8px; overflow: hidden; border: 1px solid #e2e8f0; display: flex; flex-direction: column; }

.panel-header-dark { padding: 8px 12px; background: #1e293b; display: flex; justify-content: space-between; align-items: center; font-family: 'Inter'; font-weight: 800; font-size: 11px; color: #94a3b8; }
.panel-header-light { padding: 10px 12px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; }
.panel-header-light h3 { margin: 0; font-size: 12px; color: #475569; font-weight: 800; letter-spacing: 0.5px; }

/* Camera */
.camera-box { flex: 0 0 200px; display: flex; flex-direction: column; }
.camera-content { flex: 1; position: relative; background: #000; }
.status-rec { color: #ef4444; animation: blink 1s infinite; font-weight: 700; font-size: 10px; }
.status-idle { color: #64748b; font-size: 10px; }
.hud-overlay { position: absolute; inset: 0; padding: 8px; display: flex; flex-direction: column; justify-content: space-between; pointer-events: none; }
.hud-row { display: flex; justify-content: space-between; color: rgba(255,255,255,0.6); font-family: 'Consolas', monospace; font-size: 10px; }
.crosshair { position: absolute; top: 50%; left: 50%; width: 10px; height: 10px; border: 1px solid rgba(255,255,255,0.4); transform: translate(-50%, -50%); }

/* Templates */
.template-box { flex: 0 0 160px; }
.tpl-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; padding: 8px; overflow-y: auto; }
.tpl-item { background: #fff; border: 1px solid #e2e8f0; padding: 8px; border-radius: 6px; display: flex; flex-direction: column; align-items: center; cursor: pointer; transition: all 0.2s; }
.tpl-item:hover { border-color: #3b82f6; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
.tpl-icon { font-size: 20px; margin-bottom: 4px; }
.tpl-name { font-size: 12px; font-weight: 500; color: #334155; }

/* Tabs */
.tabs-header { display: flex; background: #e2e8f0; height: 40px; }
.tab-btn { flex: 1; border: none; background: #e2e8f0; color: #64748b; font-family: 'Inter'; font-weight: 700; font-size: 12px; cursor: pointer; transition: all 0.2s; border-bottom: 2px solid transparent; }
.tab-btn.active { background: #fff; color: #3b82f6; border-bottom-color: #3b82f6; }
.tab-btn:hover:not(.active) { color: #334155; }

.tab-content { flex: 1; padding: 12px; overflow-y: auto; display: flex; flex-direction: column; }
.tab-content.bg-dark { background: #0f172a; } /* Operation Tab: Dark */
.tab-content.bg-light { background: #fff; }    /* Logs Tab: Light */

.spacer { height: 12px; }

/* Animations */
@keyframes blink { 50% { opacity: 0; } }
.custom-scroll-light::-webkit-scrollbar { width: 4px; }
.custom-scroll-light::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 2px;