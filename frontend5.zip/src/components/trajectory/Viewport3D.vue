\<template>
  <div class="viewport-box" ref="containerRef">
    <div class="toolbar">
      <div class="tool-group">
        <button :class="{active: drawMode==='select'}" @click="drawMode='select'">SELECT</button>
        <button :class="{active: drawMode==='add'}" @click="drawMode='add'">DRAW</button>
      </div>
      <div class="tool-group">
        <label><input type="checkbox" v-model="snap"> SNAP</label>
      </div>
    </div>
    <canvas ref="canvasRef"></canvas>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { TransformControls } from 'three/examples/jsm/controls/TransformControls'

const props = defineProps<{
  points: any[],
  selectedIndex: number,
  joints: number[],
  status: string
}>()
const emit = defineEmits(['update:points', 'select'])

const containerRef = ref<HTMLDivElement>()
const canvasRef = ref<HTMLCanvasElement>()
const drawMode = ref('select')
const snap = ref(false)

// Three.js Objects
let scene: THREE.Scene, camera: THREE.PerspectiveCamera, renderer: THREE.WebGLRenderer
let controls: OrbitControls, transform: TransformControls
let raycaster: THREE.Raycaster, pointer: THREE.Vector2
let pointMeshes: THREE.Mesh[] = []
let lineObj: THREE.Line
// Robot Parts
const robotParts: THREE.Object3D[] = [] // [J1, J2, J3, J4, J5, J6]

onMounted(() => {
  initThree()
  animate()
  window.addEventListener('resize', onResize)
  canvasRef.value?.addEventListener('mousedown', onPointerDown)
})

onUnmounted(() => {
  window.removeEventListener('resize', onResize)
})

// 监听关节变化 -> 驱动模型
watch(() => props.joints, (vals) => {
  if (robotParts.length < 6) return
  // 假设: J1(Y), J2(X), J3(X), J4(X), J5(Y), J6(X) 
  // 需根据实际机器人DH参数调整轴向
  const rad = (deg: number) => deg * Math.PI / 180
  robotParts[0].rotation.y = rad(vals[0])
  robotParts[1].rotation.x = rad(vals[1])
  robotParts[2].rotation.x = rad(vals[2])
  robotParts[3].rotation.x = rad(vals[3])
  robotParts[4].rotation.y = rad(vals[4])
  robotParts[5].rotation.x = rad(vals[5])
})

// 监听点位 -> 更新画面
watch(() => props.points, renderPoints, { deep: true })
watch(() => props.selectedIndex, (idx) => {
  if (idx === -1) transform.detach()
  else if (pointMeshes[idx]) transform.attach(pointMeshes[idx])
})

function initThree() {
  if (!containerRef.value || !canvasRef.value) return
  const w = containerRef.value.clientWidth
  const h = containerRef.value.clientHeight

  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x0a0a0a)
  scene.fog = new THREE.Fog(0x0a0a0a, 500, 3000)

  camera = new THREE.PerspectiveCamera(45, w/h, 1, 5000)
  camera.position.set(800, 600, 800)
  camera.lookAt(0, 200, 0)

  renderer = new THREE.WebGLRenderer({ canvas: canvasRef.value, antialias: true })
  renderer.setSize(w, h)
  renderer.shadowMap.enabled = true

  // Lights
  const amb = new THREE.AmbientLight(0xffffff, 0.4)
  scene.add(amb)
  const dir = new THREE.DirectionalLight(0xffffff, 1)
  dir.position.set(200, 500, 200)
  scene.add(dir)

  // Grid
  scene.add(new THREE.GridHelper(2000, 40, 0x333333, 0x111111))
  
  // 1. 世界坐标系 (World Frame)
  const worldAxes = new THREE.AxesHelper(100)
  scene.add(worldAxes)

  // Controls
  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true
  transform = new TransformControls(camera, renderer.domElement)
  transform.addEventListener('dragging-changed', (e: any) => controls.enabled = !e.value)
  transform.addEventListener('change', () => {
    if (transform.object && props.selectedIndex !== -1) {
      const pos = transform.object.position
      const pts = JSON.parse(JSON.stringify(props.points))
      pts[props.selectedIndex] = { ...pts[props.selectedIndex], x: Math.round(pos.x), y: Math.round(pos.z), z: Math.round(pos.y) }
      emit('update:points', pts)
    }
  })
  scene.add(transform)

  raycaster = new THREE.Raycaster()
  pointer = new THREE.Vector2()

  buildRobot()
  renderPoints()
}

function buildRobot() {
  const matBody = new THREE.MeshPhongMaterial({ color: 0x475569 })
  const matJoint = new THREE.MeshPhongMaterial({ color: 0x64748b })
  const matTool = new THREE.MeshPhongMaterial({ color: 0xf59e0b })

  // Base (Fixed)
  const base = new THREE.Mesh(new THREE.CylinderGeometry(60, 80, 40, 32), matBody)
  base.position.y = 20
  scene.add(base)
  
  // 2. 基座坐标系 (Base Frame)
  const baseAxes = new THREE.AxesHelper(80)
  baseAxes.position.y = 40
  base.add(baseAxes)

  // J1 (Waist) - Y轴旋转
  const j1 = new THREE.Group()
  j1.position.y = 20
  base.add(j1)
  robotParts.push(j1)

  // Link 1
  const link1 = new THREE.Mesh(new THREE.BoxGeometry(50, 100, 50), matJoint)
  link1.position.y = 50
  j1.add(link1)

  // J2 (Shoulder) - X轴旋转
  const j2 = new THREE.Group()
  j2.position.y = 50
  link1.add(j2)
  robotParts.push(j2)

  // Link 2
  const link2 = new THREE.Mesh(new THREE.BoxGeometry(40, 150, 40), matBody)
  link2.position.y = 75
  j2.add(link2)

  // J3 (Elbow) - X轴旋转
  const j3 = new THREE.Group()
  j3.position.y = 75
  link2.add(j3)
  robotParts.push(j3)

  // Link 3
  const link3 = new THREE.Mesh(new THREE.BoxGeometry(35, 120, 35), matJoint)
  link3.position.y = 60
  j3.add(link3)

  // ...简化 J4, J5... 为了代码简洁，直接连 J6
  
  // J6 (Wrist)
  const j6 = new THREE.Group()
  j6.position.y = 60
  link3.add(j6)
  // Fill dummy for J4, J5 indices
  robotParts.push(new THREE.Group(), new THREE.Group(), j6)

  // Flange