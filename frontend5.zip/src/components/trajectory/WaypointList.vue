<template>
  <div class="wp-panel">
    <div class="header">
      <span class="title">#</span>
      <span class="title type">TYPE</span>
      <span class="title coords">X / Y / Z (mm)</span>
      <span class="title del">ACT</span>
    </div>
    <div class="list custom-scroll-light">
      <div 
        v-for="(p, i) in points" 
        :key="i"
        class="row"
        :class="{ active: selectedIndex === i }"
        @click="$emit('select', i)"
      >
        <span class="idx">{{ i+1 }}</span>
        <div class="type-cell">
          <span class="badge" :class="p.type">{{ p.type }}</span>
        </div>
        <div class="inputs">
          <input v-model.number="p.x" @input="$emit('update')">
          <input v-model.number="p.y" @input="$emit('update')">
          <input v-model.number="p.z" @input="$emit('update')">
        </div>
        <button class="del" @click.stop="$emit('remove', i)">×</button>
      </div>
      <button class="add-btn" @click="$emit('add')">+ ADD POINT</button>
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{ points: any[], selectedIndex: number }>()
defineEmits(['select', 'update', 'remove', 'add'])
</script>

<style scoped>
.wp-panel { flex: 1; display: flex; flex-direction: column; background: #fff; overflow: hidden; }
.header { display: flex; padding: 8px; background: #f1f5f9; border-bottom: 1px solid #e2e8f0; font-size: 1