import { createRouter, createWebHistory } from 'vue-router'
// 引入您的组件
import LoginView from '../views/LoginView.vue'
import TrajectoryView from '../views/TrajectoryView.vue'
import AdminDashboard from '../views/AdminDashboard.vue' // 下一步创建

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/login'
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView
    },
    {
      path: '/trajectory',
      name: 'trajectory',
      component: TrajectoryView,
      meta: { requiresAuth: true, role: 'user' }
    },
    {
      path: '/admin',
      name: 'admin',
      component: AdminDashboard,
      meta: { requiresAuth: true, role: 'admin' }
    }
  ]
})

// 路由守卫
router.beforeEach((to,_from, next) => {
  const role = localStorage.getItem('user_role')
  
  if (to.meta.requiresAuth && !role) {
    next('/login')
  } else if (to.meta.role && to.meta.role !== role) {
    // 权限不匹配，踢回登录或对应主页
    if (role === 'admin') next('/admin')
    else if (role === 'user') next('/trajectory')
    else next('/login')
  } else {
    next()
  }
})

export default router