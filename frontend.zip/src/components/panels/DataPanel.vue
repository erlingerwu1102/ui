<template>
  <div class="data-panel">
    <div class="panel-header">
      <span class="title">SYSTEM TELEMETRY</span>
      <div class="status-indicator" :class="status">
        <span class="dot"></span>
        {{ status.toUpperCase() }}
      </div>
    </div>

    <div class="telemetry-grid">
      <div class="t-card">
        <label>X-AXIS</label>
        <span class="value">{{ pos.x.toFixed(3) }}</span>
      </div>
      <div class="t-card">
        <label>Y-AXIS</label>
        <span class="value">{{ pos.y.toFixed(3) }}</span>
      </div>
      <div class="t-card">
        <label>Z-AXIS</label>
        <span class="value">{{ pos.z.toFixed(3) }}</span>
      </div>
      <div class="t-card">
        <label>PROGRESS</label>
        <span class="value highlight">{{ Math.floor(progress) }}%</span>
      </div>
    </div>

    <div class="logs-wrapper">
      <div class="log-header">
        <span>EVENT LOGS</span>
        <button class="clear-btn" @click="logs = []">CLEAR</button>
      </div>
      <div class="log-console" ref="logContainer">
        <div v-if="logs.length === 0" class="empty-log">-- No events --</div>
        <div v-for="(log, i) in logs" :key="i" class="log-line" :class="log.type">
          <span class="time">[{{ log.time }}]</span>
          <span class="msg">{{ log.msg }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import { shotApi } from '@/api/shot'

// 数据状态
const pos = ref({ x: 0, y: 0, z: 0 })
const status = ref<'idle' | 'running' | 'error'>('idle')
const progress = ref(0)
const logs = ref<{ time: string; msg: string; type: string }[]>([])
const logContainer = ref<HTMLElement | null>(null)

// 轮询更新
let timer: any = null

const pollStatus = async () => {
  try {
    const res = await shotApi.getStatus()
    if (res.data.code === 200) {
      const d = res.data.data
      
      // 更新坐标
      if (d.current_pos) {
        pos.value = { x: d.current_pos[0], y: d.current_pos[1], z: d.current_pos[2] }
      }
      
      // 更新状态与进度
      status.value = d.status
      progress.value = d.progress || 0

      // 如果有新的操作消息，且与上一条不同，则推入日志
      if (d.current_operation && (!logs.value.length || logs.value[logs.value.length-1].msg !== d.current_operation)) {
        addLog(d.current_operation, 'info')
      }
      // 如果有错误消息
      if (d.error_message) {
        addLog(d.error_message, 'error')
      }
    }
  } catch (e) {
    status.value = 'error'
  }
}

const addLog = (msg: string, type: 'info'|'error' = 'info') => {
  const time = new Date().toLocaleTimeString('en-US', { hour12: false })
  logs.value.push({ time, msg, type })
  // 自动滚动到底部
  nextTick(() => {
    if (logContainer.value) {
      logContainer.value.scrollTop = logContainer.value.scrollHeight
    }
  })
}

onMounted(() => {
  pollStatus()
  timer = setInterval(pollStatus, 200) // 200ms 刷新率
})

onUnmounted(() => clearInterval(timer))
</script>

<style scoped>
.data-panel { height: 100%; display: flex; flex-direction: column; padding: 16px; gap: 20px; }

/* 头部 */
.panel-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid var(--border); }
.title { font-size: 11px; font-weight: 800; color: var(--text); opacity: 0.5; letter-spacing: 1px; }

.status-indicator { font-size: 10px; font-weight: bold; display: flex; align-items: center; gap: 6px; padding: 2px 8px; border-radius: 10px; background: var(--border); color: var(--text); }
.dot { width: 6px; height: 6px; border-radius: 50%; background: #9ca3af; }
.status-indicator.running .dot { background: #eab308; box-shadow: 0 0 8px #eab308; }
.status-indicator.running { color: #ca8a04; background: #fef9c3; }
.status-indicator.idle .dot { background: #22c55e; }
.status-indicator.error .dot { background: #ef4444; }

/* 坐标网格 */
.telemetry-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.t-card { background: var(--bg-app); border: 1px solid var(--border); padding: 8px 12px; border-radius: 6px; display: flex; flex-direction: column; }
.t-card label { font-size: 9px; color: var(--text); opacity: 0.6; font-weight: bold; margin-bottom: 4px; }
.t-card .value { font-family: 'JetBrains Mono', monospace; font-size: 14px; color: var(--text); font-weight: 600; }
.t-card .value.highlight { color: var(--accent); }

/* 日志区 */
.logs-wrapper { flex: 1; display: flex; flex-direction: column; min-height: 0; border: 1px solid var(--border); border-radius: 6px; overflow: hidden; }
.log-header { background: var(--bg-app); padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); }
.log-header span { font-size: 10px; font-weight: bold; opacity: 0.7; }
.clear-btn { background: none; border: none; font-size: 9px; cursor: pointer; color: var(--accent); }

.log-console { flex: 1; background: var(--bg-panel); padding: 10px; overflow-y: auto; font-family: 'JetBrains Mono', monospace; font-size: 11px; }
.log-line { margin-bottom: 4px; line-height: 1.4; display: flex; gap: 8px; }
.log-line .time { color: var(--text); opacity: 0.4; flex-shrink: 0; }
.log-line.info .msg { color: var(--text); opacity: 0.9; }
.log-line.error .msg { color: #ef4444; }
.empty-log { color: var(--text); opacity: 0.3; text-align: center; margin-top: 20px; font-style: italic; }
</style>