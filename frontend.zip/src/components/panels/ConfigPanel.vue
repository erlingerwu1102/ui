<template>
  <div class="p-container">
    <div class="p-header">RUN PARAMETERS</div>
    <div class="p-content">
      <div class="form-item">
        <label>运动时长 (Duration)</label>
        <input type="number" v-model="duration" min="1" />
      </div>
      <div class="form-item">
        <label>碰撞检测</label>
        <button @click="toggleCollision" :class="{ active: collision }">
          {{ collision ? 'ON' : 'OFF' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { shotApi } from '@/api/shot'

const duration = ref(10)
const collision = ref(false)
const emit = defineEmits(['update:duration']) // 传给父组件

watch(duration, (val) => emit('update:duration', val))

const toggleCollision = async () => {
  collision.value = !collision.value
  await shotApi.setCollision(collision.value)
}
</script>

<style scoped>
.p-container { padding: 16px; height: 100%; }
.p-header { font-size: 12px; font-weight: bold; color: var(--accent); margin-bottom: 16px; letter-spacing: 1px; }
.form-item { margin-bottom: 12px; }
.form-item label { display: block; font-size: 12px; margin-bottom: 4px; opacity: 0.7; }
input { width: 100%; padding: 8px; background: var(--bg-app); border: 1px solid var(--border); color: var(--text); border-radius: 4px; }
button.active { background: var(--accent); color: white; }
</style>