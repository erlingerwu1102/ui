<template>
  <div class="swiftmate-app" :class="themeMode">
    <header class="app-header">
      <div class="brand">
        <div class="logo-box">S</div>
        <h1>SwiftMate <span class="pro-tag">PRO</span></h1>
      </div>
      <div class="header-right">
        <ThemeSwitch v-model="themeMode" />
      </div>
    </header>

    <main class="app-body">
      <aside class="panel left" :class="{ focused: activePanel === 'left' }" @click.capture="activePanel = 'left'">
        <slot name="left"></slot>
      </aside>

      <section class="panel center" :class="{ focused: activePanel === 'center' }" @click.capture="activePanel = 'center'">
        <slot name="center"></slot>
      </section>

      <aside class="panel right" :class="{ focused: activePanel === 'right' }" @click.capture="activePanel = 'right'">
        <slot name="right"></slot>
      </aside>
    </main>

    <footer class="app-footer">
      <span>SDK Status: Connected</span>
      <span>Mode: {{ themeMode === 'light' ? 'Professional Light' : 'Industrial Dark' }}</span>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import ThemeSwitch from '../common/ThemeSwitch.vue'

const themeMode = ref<'light' | 'dark'>('light')
const activePanel = ref<'left' | 'center' | 'right'>('center')
</script>

<style scoped>
/* 主题变量定义 */
.swiftmate-app {
  --bg-app: #f2f4f7; --bg-panel: #ffffff; --text: #1d2129; --accent: #3b82f6; --border: #e5e6eb;
  height: 100vh; display: flex; flex-direction: column; background: var(--bg-app); color: var(--text);
  transition: all 0.3s ease;
}
.swiftmate-app.dark {
  --bg-app: #000000; --bg-panel: #141414; --text: #c9cdd4; --accent: #4096ff; --border: #272727;
}

.app-header {
  height: 48px; background: var(--bg-panel); border-bottom: 1px solid var(--border);
  display: flex; justify-content: space-between; align-items: center; padding: 0 16px;
}
.brand { display: flex; align-items: center; gap: 8px; font-weight: 800; }
.logo-box { background: var(--accent); color: #fff; width: 24px; height: 24px; border-radius: 4px; display: grid; place-items: center; }

.app-body { flex: 1; display: flex; padding: 8px; gap: 8px; overflow: hidden; }

/* 弹性面板逻辑：点击放大且不影响其他两栏最小宽度 */
.panel {
  background: var(--bg-panel); border: 1px solid var(--border); border-radius: 8px;
  display: flex; flex-direction: column; overflow: hidden;
  transition: flex 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
  min-width: 240px; /* 保证即便被挤压也能看到内容 */
}

/* 初始比例 2:5:2 */
.left { flex: 2; } .center { flex: 5; } .right { flex: 2; }

/* 聚焦状态：放大当前，压缩其他 */
.left.focused { flex: 4.5; }
.right.focused { flex: 4.5; }
.center.focused { flex: 7; }

/* 联动压缩逻辑：当侧边放大时，中间适当缩小 */
.app-body:has(.left.focused) .center { flex: 3.5; }
.app-body:has(.right.focused) .center { flex: 3.5; }

.app-footer { height: 24px; background: var(--bg-panel); border-top: 1px solid var(--border); font-size: 10px; display: flex; align-items: center; padding: 0 12px; gap: 20px; opacity: 0.6; }
</style>