<template>
  <button class="theme-switch" @click="toggle" :title="isDark ? '切换到亮色模式' : '切换到深色模式'">
    <div class="track">
      <div class="thumb" :class="{ 'is-dark': isDark }">
        <span class="icon">{{ isDark ? '🌙' : '☀️' }}</span>
      </div>
    </div>
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  modelValue: 'light' | 'dark'
}>()

const emit = defineEmits(['update:modelValue'])

const isDark = computed(() => props.modelValue === 'dark')

const toggle = () => {
  const newVal = isDark.value ? 'light' : 'dark'
  emit('update:modelValue', newVal)
}
</script>

<style scoped>
.theme-switch {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
}

.track {
  width: 44px;
  height: 24px;
  background-color: var(--border);
  border-radius: 12px;
  position: relative;
  transition: background-color 0.3s;
}

.thumb {
  width: 20px;
  height: 20px;
  background-color: var(--bg-panel);
  border-radius: 50%;
  position: absolute;
  top: 2px;
  left: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 1px 3px rgba(0,0,0,0.2);
  transition: transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.thumb.is-dark {
  transform: translateX(20px);
  background-color: #333;
}

.icon {
  font-size: 12px;
  line-height: 1;
}
</style>