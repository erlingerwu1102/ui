import axios from 'axios'
import type { SdkResponse, RobotStatus, Point } from '@/types/sdk'

// 对接 backend/app/routes.py 定义的 /api/v1
const api = axios.create({
  baseURL: '/api/v1',
  timeout: 5000,
  headers: { 'Content-Type': 'application/json' }
})

export const shotApi = {
  // GET /api/v1/status
  getStatus: () => api.get<SdkResponse<RobotStatus>>('/status'),

  // POST /api/v1/path
  startPath: (path: Point[], duration: number) => {
    // 安全映射：像素 -> 米
    const SCALE = 0.0001; 
    const HOME = { x: 0.25, y: 0.0, z: 0.2 };
    
    if (!path.length) return Promise.reject('Empty path');
    const startPt = path[0] as any;

    const fixedPath = path.map(p => {
      const pt = p as any;
      return {
        ...p,
        x: (pt.x - startPt.x) * SCALE + HOME.x,
        y: (pt.y - startPt.y) * SCALE + HOME.y,
        z: ((pt.z || 0) - (startPt.z || 0)) * SCALE + HOME.z
      };
    });

    return api.post<SdkResponse>('/path', { path: fixedPath, duration });
  },

  // POST /api/v1/emergency/stop
  stop: () => api.post<SdkResponse>('/emergency/stop'),

  // POST /api/v1/config/collision
  setCollision: (enabled: boolean) => api.post('/config/collision', { enabled })
}