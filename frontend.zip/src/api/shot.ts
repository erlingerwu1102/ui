import axios from 'axios'
import type { SdkResponse, RobotStatus, Point } from '@/types/sdk'

// 创建 axios 实例，基础路径指向 SDK 的 v1 接口
const api = axios.create({
  baseURL: '/api/v1',
  timeout: 5000
})

export const shotApi = {
  /**
   * 获取机器人实时状态
   * 对应后端 motion_control.get_current_status()
   */
  getStatus: () => {
    return api.get<SdkResponse<RobotStatus>>('/status')
  },

  /**
   * 下发轨迹指令
   * @param path 点位数组
   * @param duration 持续时间
   */
  startPath: (path: Point[], duration: number) => {
    // 构造符合后端预期的 payload
    return api.post<SdkResponse>('/path', {
      path,
      duration
    })
  },

  /**
   * 紧急停止
   */
  stop: () => {
    return api.post<SdkResponse>('/stop')
  },
  
  /**
   * (可选) 碰撞检测配置开关
   * 对应 routes.py 中的 /config/collision
   */
  setCollisionDetection: (enabled: boolean) => {
    return api.post<SdkResponse>('/config/collision', {
      sensitivity: 50, // 默认值
      enabled: enabled // 假设后端接口支持此字段，或根据具体实现调整
    })
  }
}