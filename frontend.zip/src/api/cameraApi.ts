// frontend/src/api/cameraApi.ts

// 模拟响应类型，保持与组件调用的接口一致
interface VirtualResponse<T> {
  data: {
    code: number;
    msg: string;
    data: T;
  }
}

// 1. 获取相机状态 (不再请求后端)
export const getCameraStatus = () => {
  return Promise.resolve({
    data: {
      code: 200,
      msg: "虚拟相机在线",
      data: {
        status: "recording", // 状态始终显示录制中
        speed: 30            // 帧率始终显示 30
      }
    }
  }) as Promise<VirtualResponse<{status: string; speed: number}>>
}

// 2. 控制相机 (点击按钮仅在控制台打印日志，不发请求)
export const controlCamera = (action: 'start' | 'stop' | 'reset') => { 
  console.log(`[虚拟相机接口] 触发动作: ${action}`);
  return Promise.resolve({
    data: {
      code: 200,
      msg: "操作成功",
      data: null
    }
  }) as Promise<VirtualResponse<null>>
}