// frontend/src/api/cameraApi.ts

//API封装文件
import axios from 'axios'
const api = axios.create({
    // 
    baseURL:'http://127.0.0.1:8000/api',// 
    timeout:10000
})
export const getCameraStatus = () =>{
    return api.get<{status:String;speed:number}>('/v1/camera/status')
}
// 修正了 comntrolCamera 的拼写错误
export const controlCamera=(action:'start'|'stop'|'reset')=>{ 
    return api.post('/v1/camera/control',{action})
}