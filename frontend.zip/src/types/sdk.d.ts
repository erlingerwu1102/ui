export interface Point {
  x: number;
  y: number;
  z?: number; // 后端允许缺省，前端补0
  r?: number; // 旋转角
}

export interface RobotStatus {
  status: 'idle' | 'running' | 'error';
  current_pos: [number, number, number]; // [x, y, z]
  current_operation: string;
  error_message: string;
  progress: number;
}

export interface SdkResponse<T = any> {
  code: number;
  msg: string;
  data: T;
}