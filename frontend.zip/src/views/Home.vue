<template>
  <MainLayout>
    <template #left>
      <div class="left-stack">
        <div class="camera-wrapper">
          <CameraView />
        </div>
        <div class="config-wrapper">
          <ConfigPanel v-model:duration="duration" />
        </div>
      </div>
    </template>

    <template #center>
      <TrajectoryCanvas :duration="duration" />
    </template>

    <template #right>
      <DataPanel />
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'

// 1. 布局组件路径
import MainLayout from '@/components/layout/MainLayout.vue'

// 2. 侧边面板组件路径 (位于 panels/ 目录)
import ConfigPanel from '@/components/panels/ConfigPanel.vue'
import DataPanel from '@/components/panels/DataPanel.vue'

// 3. 视口组件路径 (位于 viewport/ 目录)
import TrajectoryCanvas from '@/components/viewport/TrajectoryCanvas.vue'
import CameraView from '@/components/viewport/CameraView.vue'

// 共享状态
const duration = ref(10)
</script>

<style scoped>
.left-stack {
  display: flex;
  flex-direction: column;
  height: 100%;
  gap: 12px;
}
.camera-wrapper {
  flex: 1;
  min-height: 200px;
  background: #000;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid var(--border);
}
.config-wrapper {
  flex: 0 0 auto;
}
</style>