<template>
  <MainLayout>
    <template #left>
      <div class="left-stack">
        <div class="camera-wrapper">
          <CameraView />
        </div>
        <div class="config-wrapper">
          <ConfigPanel v-model:duration="duration" />
        </div>
      </div>
    </template>

    <template #center>
      <TrajectoryCanvas :duration="duration" />
    </template>

    <template #right>
      <DataPanel />
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'

// 布局组件
import MainLayout from '@/components/layout/MainLayout.vue'

// 功能组件 
// 注意：请根据你实际存放这些 .vue 文件的路径调整 import 路径
// 假设它们都在 @/components/ 下，如果是其他位置请修改
import CameraView from '@/components/CameraView.vue'
import ConfigPanel from '@/components/ConfigPanel.vue'
import TrajectoryCanvas from '@/components/TrajectoryCanvas.vue'
import DataPanel from '@/components/DataPanel.vue'

// 状态管理：定义运动时长，并在 ConfigPanel 和 TrajectoryCanvas 之间共享
const duration = ref(10)
</script>

<style scoped>
.left-stack {
  display: flex;
  flex-direction: column;
  height: 100%;
  gap: 12px;
}

.camera-wrapper {
  flex: 1; /* 占据剩余空间 */
  min-height: 200px;
  background: #000;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid var(--border);
}

.config-wrapper {
  flex: 0 0 auto; /* 高度由内容决定，不拉伸 */
}
</style>