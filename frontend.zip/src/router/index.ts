import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import MainLayout from '@/layouts/MainLayout.vue'
import TrajectoryView from '@/views/TrajectoryView.vue'
import DiagnosticsView from '@/views/DiagnosticsView.vue'

// 1. 显式定义类型，确保导出被读取
const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    component: MainLayout,
    children: [
      {
        path: '',
        name: '轨迹控制看板',
        component: TrajectoryView
      },
      {
        path: 'diagnostics',
        name: '动力学辨识',
        component: DiagnosticsView
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes // 修正：确保 routes 被传入此处
})

export default router