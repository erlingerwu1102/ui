import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
// 修正：路径改为实际存放位置
import MainLayout from "@/components/layout/MainLayout.vue"
import TrajectoryView from '@/views/TrajectoryView.vue'
// 注意：如果 DiagnosticsView 尚未创建，可以暂时注释掉
// import DiagnosticsView from '@/views/DiagnosticsView.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    component: MainLayout,
    children: [
      {
        path: '',
        name: '轨迹控制看板',
        component: TrajectoryView
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router