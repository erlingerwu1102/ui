<template>
  <div class="layout-container">
    <aside class="sidebar">
      <div class="brand">
        <img src="@/assets/logo.png" alt="Logo" class="logo" />
        <div class="brand-info">
          <span class="brand-text">SWIFTMATE</span>
          <span class="brand-ver">SDK PRO v2.1</span>
        </div>
      </div>
      
      <nav class="nav-menu">
        <router-link to="/" class="nav-item" active-class="active">
          <span class="icon">◎</span>
          <span class="label">轨迹控制看板</span>
        </router-link>
        
        <router-link to="/diagnostics" class="nav-item" active-class="active">
          <span class="icon">∿</span>
          <span class="label">动力学辨识</span>
        </router-link>

        <div class="nav-divider"></div>

        <div class="nav-group-label">系统管理</div>
        <a class="nav-item disabled">
          <span class="icon">⚙</span>
          <span class="label">全局参数设置</span>
        </a>
        <a class="nav-item disabled">
          <span class="icon">🛡</span>
          <span class="label">安全阈值配置</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <div class="connection-status">
          <span class="pulse-dot"></span>
          SDK SERVER: 8000
        </div>
      </div>
    </aside>

    <div class="main-wrapper">
      <header class="top-bar">
        <div class="breadcrumbs">
          <span class="crumb-root">工作空间</span>
          <span class="separator">/</span>
          <span class="crumb-current">{{ route.name || '未命名页面' }}</span>
        </div>

        <div class="global-status">
          <div class="status-pill success">
            <span class="dot"></span> 系统在线
          </div>
          <div class="status-pill info">
            <span class="icon">⚡</span> 动力正常
          </div>
          <div class="divider-v"></div>
          <button class="user-profile">
            <span class="avatar">AD</span>
            管理员
          </button>
        </div>
      </header>

      <main class="content-area">
        <router-view v-slot="{ Component }">
          <transition name="page-fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'

/**
 * 核心修正：
 * 通过 useRoute() 钩子获取当前路由对象。
 * 这样可以解决在 template 中直接使用 $route 导致的类型推断报错。
 */
const route = useRoute()
</script>

<style scoped>
/* 引入专业字体 */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap');

.layout-container {
  display: flex;
  height: 100vh;
  width: 100vw;
  background: #f8fafc;
  font-family: 'Inter', -apple-system, sans-serif;
  overflow: hidden;
}

/* 侧边栏样式 */
.sidebar {
  width: 260px;
  background: #0f172a; /* 深蓝色背景 */
  color: #94a3b8;
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  box-shadow: 4px 0 10px rgba(0,0,0,0.1);
  z-index: 100;
}

.brand {
  height: 72px;
  display: flex;
  align-items: center;
  padding: 0 24px;
  gap: 12px;
  border-bottom: 1px solid #1e293b;
}

.logo {
  height: 32px;
  filter: drop-shadow(0 0 4px rgba(59, 130, 246, 0.5));
}

.brand-info {
  display: flex;
  flex-direction: column;
}

.brand-text {
  color: white;
  font-weight: 800;
  font-size: 16px;
  letter-spacing: 1px;
}

.brand-ver {
  font-size: 10px;
  color: #475569;
  font-family: 'JetBrains Mono', monospace;
}

.nav-menu {
  padding: 24px 16px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.nav-group-label {
  font-size: 10px;
  font-weight: 700;
  color: #475569;
  padding: 16px 16px 8px;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-radius: 8px;
  color: #94a3b8;
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
}

.nav-item:hover:not(.disabled) {
  background: #1e293b;
  color: #f1f5f9;
}

.nav-item.active {
  background: #3b82f6; /* 主题蓝 */
  color: white;
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
}

.nav-item.disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.nav-divider {
  height: 1px;
  background: #1e293b;
  margin: 16px 12px;
}

.sidebar-footer {
  padding: 20px 24px;
  background: #020617;
  border-top: 1px solid #1e293b;
}

.connection-status {
  font-size: 11px;
  font-family: 'JetBrains Mono', monospace;
  display: flex;
  align-items: center;
  gap: 8px;
}

.pulse-dot {
  width: 8px;
  height: 8px;
  background: #10b981;
  border-radius: 50%;
  animation: pulse 2s infinite;
}

/* 右侧包裹区 */
.main-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.top-bar {
  height: 72px;
  background: white;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 32px;
  flex-shrink: 0;
}

.breadcrumbs {
  font-size: 14px;
  color: #64748b;
  display: flex;
  align-items: center;
}

.crumb-root {
  font-weight: 500;
}

.separator {
  margin: 0 10px;
  color: #cbd5e1;
}

.crumb-current {
  color: #0f172a;
  font-weight: 700;
}

.global-status {
  display: flex;
  align-items: center;
  gap: 12px;
}

.status-pill {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  border-radius: 100px;
  font-size: 12px;
  font-weight: 700;
  border: 1px solid transparent;
}

.status-pill.success {
  color: #10b981;
  background: #ecfdf5;
  border-color: #d1fae5;
}

.status-pill.info {
  color: #3b82f6;
  background: #eff6ff;
  border-color: #dbeafe;
}

.dot {
  width: 6px;
  height: 6px;
  background: currentColor;
  border-radius: 50%;
}

.divider-v {
  width: 1px;
  height: 24px;
  background: #e2e8f0;
  margin: 0 8px;
}

.user-profile {
  display: flex;
  align-items: center;
  gap: 10px;
  border: none;
  background: none;
  font-size: 13px;
  font-weight: 600;
  color: #475569;
  cursor: pointer;
}

.avatar {
  width: 32px;
  height: 32px;
  background: #f1f5f9;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  color: #64748b;
  border: 1px solid #e2e8f0;
}

/* 内容区域 */
.content-area {
  flex: 1;
  padding: 24px;
  overflow: hidden; /* 由子组件内部滚动 */
  position: relative;
}

/* 动画 */
.page-fade-enter-active,
.page-fade-leave-active {
  transition: opacity 0.25s ease, transform 0.25s ease;
}

.page-fade-enter-from {
  opacity: 0;
  transform: translateY(10px);
}

.page-fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

@keyframes pulse {
  0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
  70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
  100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}
</style>