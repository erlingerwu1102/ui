import { defineConfig } from 'vite'
// vite.config.ts
export default defineConfig({
  // ... 其他配置
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {  
      '/api': {
        // 将 localhost 改为 127.0.0.1 避免 IPv6 解析冲突
        target: 'http://127.0.0.1:8000', 
        changeOrigin: true,       
      }
    }
  }
})