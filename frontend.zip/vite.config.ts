import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [vue()],
  
  // 1. 路径别名配置 (解决 src/router/index.ts 找不到 @ 的问题)
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },

  server: {
    host: '0.0.0.0', // 允许局域网访问
    port: 5173,
    // 2. 代理配置 (核心修复点)
    proxy: {  
      '/api': {
        target: 'http://127.0.0.1:8000', 
        changeOrigin: true,
        // 注意：根据您的后端 routes.py，路由前缀本身就是 /api/v1
        // 所以这里不需要 rewrite (重写) 路径，直接转发即可
      }
    }
  }
})