<template>
  <MainLayout>
    <template #left>
      <div class="split-column">
        <div class="camera-zone">
          <CameraView />
        </div>
        <div class="config-zone">
          <ConfigPanel v-model:duration="duration" />
        </div>
      </div>
    </template>

    <template #center>
      <div class="viewport-full">
        <TrajectoryCanvas :duration="duration" />
        
        <div class="overlay-hint">
          <span>INTERACTIVE MODE</span>
        </div>
      </div>
    </template>

    <template #right>
      <div class="telemetry-full">
        <DataPanel />
      </div>
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'

// 导入布局
import MainLayout from '@/layouts/MainLayout.vue'

// 导入功能组件 (请确保文件存在于对应路径)
import CameraView from '@/components/viewport/CameraView.vue'
import TrajectoryCanvas from '@/components/viewport/TrajectoryCanvas.vue'
import ConfigPanel from '@/components/panels/ConfigPanel.vue'
import DataPanel from '@/components/panels/DataPanel.vue'

// 状态共享
const duration = ref(10)
</script>

<style scoped>
/* 左侧垂直分栏样式 */
.split-column {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.camera-zone {
  flex: 0 0 220px; /* 固定高度，预留给视频 */
  background: #000;
  border-bottom: 1px solid var(--border-color);
  position: relative;
  overflow: hidden;
}
.config-zone {
  flex: 1; /* 剩余空间给配置 */
  overflow-y: auto;
  background: var(--bg-panel);
}

/* 中间区域样式 */
.viewport-full {
  width: 100%;
  height: 100%;
  position: relative;
  background: #f8fafc;
}
.overlay-hint {
  position: absolute;
  top: 10px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0,0,0,0.6);
  color: white;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 10px;
  font-weight: 600;
  pointer-events: none;
  backdrop-filter: blur(4px);
}

/* 右侧区域样式 */
.telemetry-full {
  height: 100%;
  width: 100%;
}
</style>