<template>
  <div class="viewport">
    <svg id="canvas" viewBox="0 0 800 400" @click="addPoint" @mousemove="onDrag">
      <rect width="800" height="400" fill="url(#grid-pattern)" />
      
      <path :d="pathD" stroke="var(--accent)" stroke-width="3" fill="none" />
      
      <circle v-for="(p, i) in points" :key="i" 
        :cx="p.x" :cy="p.y" r="6" fill="var(--text)"
        @mousedown.stop="startDrag(i)" @mouseup="stopDrag" 
      />
    </svg>
    
    <div class="float-bar">
      <button class="btn primary" @click="runTask">▶ 开始执行</button>
      <button class="btn danger" @click="stopTask">⏹ 急停</button>
      <button class="btn" @click="points=[]">🗑 清空</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { shotApi } from '@/api/shot'
import type { Point } from '@/types/sdk'

const props = defineProps<{ duration: number }>() // 接收左侧配置
const points = ref<Point[]>([])
const dragIdx = ref(-1)

// 贝塞尔曲线生成 (简化版)
const pathD = computed(() => {
  if (points.value.length < 2) return ''
  return `M ${points.value.map(p => `${p.x},${p.y}`).join(' L ')}`
})

const addPoint = (e: MouseEvent) => {
  // SVG坐标转换逻辑略 (参考之前代码)
  points.value.push({ x: e.offsetX, y: e.offsetY, z: 0 })
}
const startDrag = (i: number) => dragIdx.value = i
const stopDrag = () => dragIdx.value = -1
const onDrag = (e: MouseEvent) => {
  if (dragIdx.value > -1) {
    points.value[dragIdx.value].x = e.offsetX
    points.value[dragIdx.value].y = e.offsetY
  }
}

const runTask = () => shotApi.startPath(points.value, props.duration)
const stopTask = () => shotApi.stop()
</script>

<style scoped>
.viewport { position: relative; width: 100%; height: 100%; background: var(--bg-app); }
svg { width: 100%; height: 100%; cursor: crosshair; }
.float-bar { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); display: flex; gap: 8px; }
.btn { padding: 8px 16px; border-radius: 20px; border: none; font-weight: bold; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.primary { background: var(--accent); color: white; }
.danger { background: #ff4d4f; color: white; }
</style>