<template>
  <div class="viewport-box" ref="containerRef">
    <div class="toolbar">
      <div class="tool-group">
        <button :class="{active: drawMode==='select'}" @click="$emit('update:drawMode', 'select')">👆 SELECT</button>
        <button :class="{active: drawMode==='add'}" @click="$emit('update:drawMode', 'add')" title="Double click to add point">➕ DRAW (DBL-CLICK)</button>
      </div>
      <div class="tool-group">
        <label><input type="checkbox" v-model="snap"> SNAP</label>
        <label><input type="checkbox" v-model="showAxes"> AXIS</label>
      </div>
    </div>
    
    <div class="coords-hud">
      POS: ({{ cursor.x.toFixed(3) }}, {{ cursor.y.toFixed(3) }}, {{ cursor.z.toFixed(3) }})
    </div>
    
    <canvas ref="canvasRef"></canvas>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, reactive } from 'vue'
import * as THREE from 'three'
// @ts-ignore
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
// @ts-ignore
import { TransformControls } from 'three/examples/jsm/controls/TransformControls'

const props = defineProps<{
  points: any[],
  selectedIndex: number,
  joints: number[],
  progress: number,
  isPlaying: boolean,
  drawMode: string
}>()
const emit = defineEmits(['update:points', 'select-point', 'update:drawMode', 'canvas-click'])

const containerRef = ref<HTMLDivElement>()
const canvasRef = ref<HTMLCanvasElement>()
const snap = ref(false)
const showAxes = ref(true)
const cursor = reactive({ x: 0, y: 0, z: 0 })

// Three.js Objects
let scene: THREE.Scene, camera: THREE.PerspectiveCamera, renderer: THREE.WebGLRenderer
let controls: OrbitControls, transform: TransformControls
let raycaster: THREE.Raycaster, pointer: THREE.Vector2
let pointMeshes: THREE.Mesh[] = []

let trajectoryLine: THREE.Line | null = null 

let robotBase: THREE.Group 
let axesHelper: THREE.AxesHelper
let gridPlane: THREE.Plane
let ghostMesh: THREE.Mesh

onMounted(() => {
  initThree()
  animate()
  window.addEventListener('resize', onResize)
  if (canvasRef.value) {
    canvasRef.value.addEventListener('pointerdown', onPointerDown)
    canvasRef.value.addEventListener('pointermove', onPointerMove)
    // 新增：双击事件监听
    canvasRef.value.addEventListener('dblclick', onDoubleClick)
  }
})

onUnmounted(() => {
  window.removeEventListener('resize', onResize)
  if (canvasRef.value) {
    canvasRef.value.removeEventListener('pointerdown', onPointerDown)
    canvasRef.value.removeEventListener('pointermove', onPointerMove)
    canvasRef.value.removeEventListener('dblclick', onDoubleClick)
  }
  renderer?.dispose()
})

// 监听轴显示
watch(showAxes, (val) => {
  if (axesHelper) axesHelper.visible = val
})

// 监听进度 -> 驱动机械臂
watch(() => props.progress, (val) => {
  if (!props.isPlaying || !props.points || props.points.length < 2) return
  const segmentCount = props.points.length - 1
  const t = val / 100 
  const currentIdx = Math.min(Math.floor(t * segmentCount), segmentCount - 1)
  const segmentT = (t * segmentCount) - currentIdx

  const p1 = props.points[currentIdx]
  const p2 = props.points[currentIdx + 1]

  if (p1 && p2 && robotBase) {
    const targetX = p1.x + (p2.x - p1.x) * segmentT
    const targetY = p1.z + (p2.z - p1.z) * segmentT
    const targetZ = p1.y + (p2.y - p1.y) * segmentT
    robotBase.position.set(targetX, targetZ, targetY)
  }
})

watch(() => props.points, renderTrajectory, { deep: true })
watch(() => props.selectedIndex, updateTransformMode)

function initThree() {
  if (!containerRef.value || !canvasRef.value) return
  const w = containerRef.value.clientWidth
  const h = containerRef.value.clientHeight

  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x020617)
  scene.fog = new THREE.Fog(0x020617, 1000, 8000)

  camera = new THREE.PerspectiveCamera(45, w/h, 1, 10000)
  camera.position.set(1000, 800, 1000)

  renderer = new THREE.WebGLRenderer({ canvas: canvasRef.value, antialias: true })
  renderer.setSize(w, h)
  renderer.setPixelRatio(window.devicePixelRatio)

  scene.add(new THREE.AmbientLight(0xffffff, 0.5))
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.8)
  dirLight.position.set(500, 1000, 500)
  scene.add(dirLight)

  const grid = new THREE.GridHelper(4000, 40, 0x334155, 0x0f172a)
  scene.add(grid)
  
  axesHelper = new THREE.AxesHelper(200)
  scene.add(axesHelper)

  gridPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0)

  // 预览球 (Ghost Mesh)
  const ghostGeo = new THREE.SphereGeometry(5, 16, 16)
  const ghostMat = new THREE.MeshBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.5 })
  ghostMesh = new THREE.Mesh(ghostGeo, ghostMat)
  ghostMesh.visible = false
  scene.add(ghostMesh)

  robotBase = new THREE.Group()
  const baseMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(40, 60, 20, 32),
    new THREE.MeshPhongMaterial({ color: 0x3b82f6 })
  )
  baseMesh.position.y = 10
  robotBase.add(baseMesh)
  scene.add(robotBase)

  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true

  transform = new TransformControls(camera, renderer.domElement)
  transform.addEventListener('dragging-changed', (e: any) => controls.enabled = !e.value)
  transform.addEventListener('change', () => {
    if (transform.object && props.selectedIndex !== -1) {
      const pos = transform.object.position
      const newPts = JSON.parse(JSON.stringify(props.points))
      if (newPts[props.selectedIndex]) {
        newPts[props.selectedIndex].x = Math.round(pos.x)
        newPts[props.selectedIndex].y = Math.round(pos.z)
        newPts[props.selectedIndex].z = Math.round(pos.y)
        emit('update:points', newPts)
      }
    }
  })
  scene.add(transform as any)

  raycaster = new THREE.Raycaster()
  pointer = new THREE.Vector2()

  renderTrajectory()
}

function updateTransformMode() {
  if (props.selectedIndex === -1) {
    transform.detach()
  } else if (pointMeshes[props.selectedIndex]) {
    transform.attach(pointMeshes[props.selectedIndex])
  }
}

function renderTrajectory() {
  if (!scene) return
  
  pointMeshes.forEach(m => scene.remove(m))
  pointMeshes = []
  
  if (trajectoryLine) scene.remove(trajectoryLine)

  if (!props.points || props.points.length === 0) return

  const sphereGeo = new THREE.SphereGeometry(8, 16, 16)
  props.points.forEach((p, i) => {
    const mat = new THREE.MeshBasicMaterial({ color: i === props.selectedIndex ? 0xf59e0b : 0x10b981 })
    const mesh = new THREE.Mesh(sphereGeo, mat)
    mesh.position.set(p.x, p.z, p.y)
    mesh.userData = { index: i }
    scene.add(mesh)
    pointMeshes.push(mesh)
  })

  updateTransformMode()

  if (props.points.length > 1) {
    const linePoints = props.points.map(p => new THREE.Vector3(p.x, p.z, p.y))
    const lineGeo = new THREE.BufferGeometry().setFromPoints(linePoints)
    const lineMat = new THREE.LineBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.6 })
    trajectoryLine = new THREE.Line(lineGeo, lineMat)
    scene.add(trajectoryLine)
  }
}

function onPointerMove(event: PointerEvent) {
  if (!canvasRef.value) return
  const rect = canvasRef.value.getBoundingClientRect()
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1

  raycaster.setFromCamera(pointer, camera)
  const target = new THREE.Vector3()
  raycaster.ray.intersectPlane(gridPlane, target)

  if (target) {
    if (snap.value) {
      target.x = Math.round(target.x / 50) * 50
      target.z = Math.round(target.z / 50) * 50
    }
    
    cursor.x = target.x
    cursor.y = target.z
    cursor.z = 0

    if (props.drawMode === 'add') {
      ghostMesh.position.copy(target)
      ghostMesh.visible = true
      document.body.style.cursor = 'crosshair'
    } else {
      ghostMesh.visible = false
      document.body.style.cursor = 'default'
    }
  }
}

// 单击逻辑：仅处理选择
function onPointerDown(event: PointerEvent) {
  if (!canvasRef.value) return
  
  const rect = canvasRef.value.getBoundingClientRect()
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  
  if (props.drawMode === 'select') {
    raycaster.setFromCamera(pointer, camera)
    const intersects = raycaster.intersectObjects(pointMeshes)
    if (intersects.length > 0) {
      const idx = intersects[0].object.userData.index
      emit('select-point', idx)
    } else {
      emit('select-point', -1)
    }
  } 
  // 注意：此处不再处理 'add' 模式
}

// 新增：双击逻辑：仅处理添加
function onDoubleClick(event: MouseEvent) {
  if (!canvasRef.value || props.drawMode !== 'add') return

  const rect = canvasRef.value.getBoundingClientRect()
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1

  raycaster.setFromCamera(pointer, camera)
  const target = new THREE.Vector3()
  raycaster.ray.intersectPlane(gridPlane, target)

  if (target) {
     if (snap.value) {
      target.x = Math.round(target.x / 50) * 50
      target.z = Math.round(target.z / 50) * 50
    }
    emit('canvas-click', { x: target.x, y: target.z, z: 0 })
  }
}

function animate() {
  requestAnimationFrame(animate)
  controls.update()
  renderer.render(scene, camera)
}

function onResize() {
  if (!containerRef.value || !camera || !renderer) return
  const w = containerRef.value.clientWidth
  const h = containerRef.value.clientHeight
  camera.aspect = w / h
  camera.updateProjectionMatrix()
  renderer.setSize(w, h)
}
</script>

<style scoped>
.viewport-box { width: 100%; height: 100%; position: relative; overflow: hidden; }
.toolbar { position: absolute; top: 10px; left: 10px; z-index: 10; display: flex; gap: 10px; }
.tool-group { background: rgba(15, 23, 42, 0.8); padding: 4px; border-radius: 4px; display: flex; gap: 4px; border: 1px solid #334155; }
button { background: transparent; border: none; color: #cbd5e1; font-size: 10px; cursor: pointer; padding: 4px 8px; font-weight: bold; border-radius: 2px; }
button.active { background: #3b82f6; color: white; }
label { color: #cbd5e1; font-size: 10px; display: flex; align-items: center; gap: 4px; padding: 0 4px; cursor: pointer; }

.coords-hud {
  position: absolute; top: 10px; right: 10px; z-index: 10;
  background: rgba(0, 0, 0, 0.7); border: 1px solid #3b82f6;
  color: #3b82f6; font-family: monospace; font-size: 11px;
  padding: 4px 8px; border-radius: 4px; pointer-events: none;
}
canvas { display: block; width: 100%; height: 100%; outline: none; }
</style>