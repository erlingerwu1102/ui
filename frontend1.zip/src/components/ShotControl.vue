<template>
  <div class="pro-app">
    <header class="row-header">
      <div class="brand-section">
        <div class="logo-big">
          <img src="@/assets/logo.png" alt="SwiftMate" />
        </div>
        <div class="brand-info">
          <h1 class="main-title">SWIFTMATE</h1>
          <span class="sub-title">SDK CLIENT</span>
        </div>
      </div>

      <div class="header-right">
        <div class="status-indicator">
          <div class="indicator-dot" :class="statusClass"></div>
          <div class="status-details">
            <span class="label">SYSTEM STATUS</span>
            <span class="value">{{ statusText }}</span>
          </div>
        </div>
        <div class="divider-v"></div>
        <div class="meta-item">
          <span class="label">MODE</span>
          <span class="value mono">{{ controlMode }}</span>
        </div>
      </div>
    </header>

    <section class="row-camera">
      <div class="camera-frame">
        <img 
  class="live-feed" 
  :src="'/api/v1/video_feed'" 
  @error="handleVideoError" 
  v-if="videoAvailable"
/>
        <div class="video-noise" v-else>
          <span>NO SIGNAL</span>
        </div>
        
        <div class="osd tl"><span class="rec-icon"></span> LIVE</div>
        <div class="osd tr mono">SDK STREAM</div>
      </div>
    </section>

    <section class="row-canvas">
      <div class="canvas-toolbar">
        <div class="tool-info">
          <span class="info-label">POINTS</span>
          <span class="info-val">{{ points.length }}</span>
        </div>
      </div>

      <div class="viewport-box" :class="{ locked: isRunning }">
        <svg 
          id="trajectory-canvas" 
          viewBox="0 0 800 400" 
          preserveAspectRatio="xMidYMid slice"
          @click="handleCanvasClick"
        >
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" stroke-width="1"/>
            </pattern>
          </defs>

          <rect width="800" height="400" fill="#ffffff"/>
          <rect width="800" height="400" fill="url(#grid)"/>
          
          <rect x="0" y="0" width="800" height="400" fill="none" stroke="#ef4444" stroke-width="1" stroke-dasharray="4,4" opacity="0.4"/>

          <path v-if="points.length > 1" :d="pathD" stroke="#0f172a" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>

          <g v-for="(pt, index) in points" :key="index">
            <circle 
              :cx="pt.x" :cy="pt.y" r="6" 
              fill="#3b82f6" 
              stroke="#fff" stroke-width="2"
            />
          </g>

          <g v-if="hasPositionData">
            <circle :cx="robotVisualPos.x" :cy="robotVisualPos.y" r="12" fill="rgba(16, 185, 129, 0.3)" />
            <circle :cx="robotVisualPos.x" :cy="robotVisualPos.y" r="6" fill="#10b981" stroke="#fff" stroke-width="2" />
            <text :x="robotVisualPos.x + 15" :y="robotVisualPos.y" font-size="10" font-family="monospace" fill="#059669">
              {{ robotWorldPos.x.toFixed(2) }}, {{ robotWorldPos.y.toFixed(2) }}
            </text>
          </g>
        </svg>

        <div class="empty-state" v-if="points.length === 0">
          <span>CLICK TO ADD WAYPOINTS</span>
        </div>
      </div>
    </section>

    <section class="row-dock">
      <div class="dock-panel console-panel">
        <div class="panel-head">
          <span>SDK MESSAGE</span>
          <span class="status-dot" :class="statusClass"></span>
        </div>
        <div class="console-window">
          <div class="log-line">
            <span class="log-time">[{{ currentTime }}]</span>
            <span class="log-msg">{{ systemMsg }}</span>
          </div>
          <div class="log-line" v-if="errorMsg">
            <span class="log-time">ERR</span>
            <span class="log-msg error">{{ errorMsg }}</span>
          </div>
        </div>
      </div>

      <div class="control-panel-wrapper">
        <div class="telemetry-row">
          <div class="t-item">
            <label>X-AXIS (m)</label>
            <span class="mono">{{ robotWorldPos.x.toFixed(3) }}</span>
          </div>
          <div class="t-item">
            <label>Y-AXIS (m)</label>
            <span class="mono">{{ robotWorldPos.y.toFixed(3) }}</span>
          </div>
          <div class="t-item">
            <label>Z-AXIS (m)</label>
            <span class="mono">{{ robotWorldPos.z.toFixed(3) }}</span>
          </div>
          <div class="t-item">
            <label>PROGRESS</label>
            <span class="mono">{{ progress }}%</span>
          </div>
        </div>

        <div class="params-row">
          <button class="btn" @click="clearPoints" :disabled="isRunning">CLEAR</button>
          
          <button class="btn primary" @click="handleExecute" :disabled="points.length < 2 || isRunning">
            <span v-if="isRunning">EXECUTING...</span>
            <span v-else>EXECUTE PATH</span>
          </button>
          
          <button class="btn danger" @click="handleStop">
            EMERGENCY STOP
          </button>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { shotApi } from '@/api/shot'
import type { Point, RobotStatus } from '@/types/sdk'

// --- 响应式状态 ---
const points = ref<Point[]>([])

// robotWorldPos: 存储 SDK 返回的真实物理坐标 (米)
const robotWorldPos = ref({ x: 0.0, y: 0.0, z: 0.0 })
// robotVisualPos: 存储映射回 800x400 画布的像素坐标
const robotVisualPos = ref({ x: 0, y: 0 })

const hasPositionData = ref(false)
const sdkStatus = ref<RobotStatus['status']>('idle')
const systemMsg = ref('Initializing...')
const errorMsg = ref('')
const progress = ref(0)
const controlMode = ref('SDK_AUTO')
const videoAvailable = ref(true)
const currentTime = ref('')

let pollTimer: number | null = null
let timeTimer: number | null = null

// --- 计算属性 ---
const isRunning = computed(() => sdkStatus.value === 'running')
const statusText = computed(() => sdkStatus.value.toUpperCase())
const statusClass = computed(() => {
  if (sdkStatus.value === 'running') return 'running'
  if (sdkStatus.value === 'error') return 'error'
  return 'ready'
})

const pathD = computed(() => {
  if (points.value.length < 2) return ''
  return `M ${points.value.map(p => `${p.x} ${p.y}`).join(' L ')}`
})

// --- 方法 ---

// 点击画布添加点 (像素坐标)
const handleCanvasClick = (e: MouseEvent) => {
  if (isRunning.value) return
  const svg = document.getElementById('trajectory-canvas') as any
  const rect = svg.getBoundingClientRect()
  const x = Math.max(0, Math.min(800, e.clientX - rect.left))
  const y = Math.max(0, Math.min(400, e.clientY - rect.top))
  
  points.value.push({ x, y })
}

const clearPoints = () => {
  points.value = []
}

const handleVideoError = () => {
  videoAvailable.value = false
  systemMsg.value = 'Camera feed unavailable'
}

// 执行任务
const handleExecute = async () => {
  if (points.value.length < 2) return
  try {
    const res = await shotApi.startPath(points.value, 10)
    if (res.data.code === 200) {
      systemMsg.value = 'Path uploaded successfully'
      errorMsg.value = ''
    } else {
      errorMsg.value = res.data.msg || 'Upload failed'
    }
  } catch (e) {
    errorMsg.value = 'Network Error: Failed to start'
  }
}

// 紧急停止
const handleStop = async () => {
  try {
    const res = await shotApi.stop()
    if (res.data.code === 200) {
      systemMsg.value = 'STOP command sent'
    }
  } catch (e) {
    console.error(e)
  }
}

const pollStatus = async () => {
  try {
    const res = await shotApi.getStatus()
    if (res.data.code === 200 && res.data.data) {
      const data = res.data.data // data 的类型现在是 RobotStatus
      
      // 1. 更新状态
      sdkStatus.value = data.status
      
      // 修复 'msg' 报错逻辑：优先使用 current_operation，没有则尝试 msg，再没有则默认 'System Ready'
      systemMsg.value = data.current_operation || data.msg || 'System Ready'
      
      errorMsg.value = data.error_message || ''
      controlMode.value = data.coordinate_system ? data.coordinate_system.toUpperCase() : 'UNKNOWN'
      
      // 2. 更新位置
      if (Array.isArray(data.current_pos) && data.current_pos.length >= 3) {
        const [wx, wy, wz] = data.current_pos
        robotWorldPos.value = { x: wx, y: wy, z: wz }
        // 简单映射：假设 1米 = 100像素，原点在 (400, 200)
        robotVisualPos.value = {
          x: wx * 100 + 400,
          y: wy * 100 + 200
        }
        hasPositionData.value = true
      }
      // 3. 修复 'number' 报错逻辑：
      // 使用 '?? 0' 运算符，如果 data.progress 不存在，则默认为 0
      progress.value = data.progress ?? 0 
    }
  } catch (e) {
    // console.error(e) // 调试时可打开
  }
}

onMounted(() => {
  pollTimer = setInterval(pollStatus, 200) as unknown as number
  
  timeTimer = setInterval(() => {
    const now = new Date()
    currentTime.value = now.toLocaleTimeString()
  }, 1000) as unknown as number
})

onUnmounted(() => {
  if (pollTimer) clearInterval(pollTimer)
  if (timeTimer) clearInterval(timeTimer)
})
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap');

.pro-app {
  --bg-main: #f8fafc; --bg-panel: #ffffff; --border: #e2e8f0; --text-main: #0f172a;
  --text-sub: #64748b; --primary: #3b82f6; --success: #10b981; --danger: #ef4444; --terminal-bg: #f1f5f9;
  font-family: 'Inter', sans-serif; background-color: var(--bg-main); color: var(--text-main);
  min-height: 100vh; display: flex; flex-direction: column; overflow-y: auto; user-select: none;
}
.mono { font-family: 'JetBrains Mono', monospace; }

/* 头部 */
.row-header { height: 70px; background: var(--bg-panel); border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; padding: 0 32px; flex-shrink: 0; }
.brand-section { display: flex; align-items: center; gap: 16px; }
.logo-big img { height: 40px; width: auto; }
.brand-info { display: flex; flex-direction: column; }
.main-title { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; line-height: 1.2; }
.sub-title { font-size: 10px; font-weight: 600; color: var(--text-sub); letter-spacing: 1.5px; }

.header-right { display: flex; align-items: center; gap: 24px; }
.status-indicator { display: flex; align-items: center; gap: 10px; }
.indicator-dot { width: 8px; height: 8px; border-radius: 50%; background: #cbd5e1; }
.indicator-dot.ready { background: var(--success); box-shadow: 0 0 8px var(--success); }
.indicator-dot.running { background: #d97706; box-shadow: 0 0 8px #d97706; }
.indicator-dot.error { background: var(--danger); box-shadow: 0 0 8px var(--danger); }
.status-details { display: flex; flex-direction: column; }
.status-details .label, .meta-item .label { font-size: 9px; font-weight: 700; color: var(--text-sub); }
.status-details .value, .meta-item .value { font-size: 13px; font-weight: 700; }
.divider-v { width: 1px; height: 24px; background: var(--border); }
.meta-item { display: flex; flex-direction: column; align-items: flex-end; }

/* 视频区 */
.row-camera { height: 240px; background: #000; flex-shrink: 0; position: relative; overflow: hidden; display: flex; justify-content: center; align-items: center; }
.camera-frame { width: 100%; height: 100%; position: relative; }
.live-feed { width: 100%; height: 100%; object-fit: contain; }
.video-noise { width: 100%; height: 100%; background: #1e293b; display: flex; align-items: center; justify-content: center; color: #475569; font-weight: 700; font-size: 12px; letter-spacing: 2px; }
.osd { position: absolute; color: white; font-size: 11px; font-weight: 600; text-shadow: 0 1px 2px rgba(0,0,0,0.8); z-index: 10; pointer-events: none; }
.tl { top: 12px; left: 16px; display: flex; align-items: center; gap: 6px; }
.tr { top: 12px; right: 16px; opacity: 0.8; }
.rec-icon { width: 8px; height: 8px; background: #ef4444; border-radius: 50%; animation: pulse 1s infinite; }

/* 画布区 */
.row-canvas { flex: 1; min-height: 300px; background: #f1f5f9; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; }
.canvas-toolbar { position: absolute; top: 16px; right: 24px; z-index: 10; }
.tool-info { text-align: right; }
.info-label { font-size: 9px; font-weight: 700; color: var(--text-sub); }
.info-val { font-size: 14px; font-weight: 700; color: var(--text-main); }
.viewport-box { width: 800px; height: 400px; background: #fff; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); border-radius: 4px; border: 1px solid #cbd5e1; cursor: crosshair; overflow: hidden; }
.viewport-box.locked { cursor: not-allowed; opacity: 0.95; }
svg { display: block; width: 100%; height: 100%; }
.empty-state { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; font-weight: 700; color: #94a3b8; pointer-events: none; }

/* 底部控制坞 */
.row-dock { height: 140px; background: var(--bg-panel); border-top: 1px solid var(--border); display: flex; padding: 0; flex-shrink: 0; }
.console-panel { flex: 0 0 320px; border-right: 1px solid var(--border); display: flex; flex-direction: column; background: var(--terminal-bg); padding: 12px 20px; }
.panel-head { display: flex; justify-content: space-between; align-items: center; font-size: 10px; font-weight: 700; color: var(--text-sub); margin-bottom: 8px; }
.status-dot { width: 6px; height: 6px; border-radius: 50%; background: #94a3b8; }
.status-dot.running { background: #d97706; }
.status-dot.error { background: var(--danger); }
.status-dot.ready { background: var(--success); }
.console-window { flex: 1; overflow-y: auto; font-family: 'JetBrains Mono', monospace; font-size: 11px; display: flex; flex-direction: column; gap: 4px; }
.log-line { display: flex; gap: 8px; }
.log-time { color: #94a3b8; flex-shrink: 0; }
.log-msg { color: var(--text-main); word-break: break-all; }
.log-msg.error { color: var(--danger); }

/* 控制面板包装 */
.control-panel-wrapper { flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; gap: 16px; padding: 0 20px; }
.telemetry-row { display: flex; gap: 48px; }
.params-row { display: flex; gap: 20px; }

/* 遥测项 */
.t-item { display: flex; flex-direction: column; align-items: center; gap: 2px; min-width: 80px; }
.t-item label { font-size: 9px; font-weight: 700; color: var(--text-sub); }
.t-item .mono { font-size: 18px; font-weight: 600; color: var(--text-main); font-family: 'JetBrains Mono', monospace; }

/* 按钮 */
.btn { height: 40px; padding: 0 24px; border: 1px solid var(--border); background: #fff; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.1s; color: var(--text-main); }
.btn:hover:not(:disabled) { background: #f1f5f9; border-color: #cbd5e1; }
.btn:disabled { opacity: 0.5; cursor: not-allowed; }
.btn.primary { background: var(--text-main); color: #fff; border: none; }
.btn.primary:hover:not(:disabled) { background: #334155; }
.btn.danger { background: var(--danger); color: #fff; border: none; }
.btn.danger:hover { background: #dc2626; }

@keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }
</style>