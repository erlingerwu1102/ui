<template>
  <div class="dashboard-grid" @mouseup="handleMouseUp" @mouseleave="handleMouseUp">
    <section class="panel visual-panel">
      <div class="panel-header">
        <div class="tabs">
          <button class="tab" :class="{ active: activeTab === 'canvas' }" @click="activeTab = 'canvas'">
            轨迹规划空间
          </button>
          <button class="tab" :class="{ active: activeTab === 'camera' }" @click="activeTab = 'camera'">
            实时视频监控 (Live)
          </button>
        </div>
        <div class="panel-tools">
          <span class="tool-item">规划点数: <strong>{{ points.length }}</strong></span>
          <span class="tool-hint" v-if="points.length > 0">（可拖动点位调整轨迹）</span>
        </div>
      </div>
      
      <div class="visual-content">
        <div v-show="activeTab === 'canvas'" class="canvas-wrapper" :class="{ locked: isRunning }">
          <svg 
            id="trajectory-canvas" 
            viewBox="0 0 800 400" 
            @click="handleCanvasClick"
            @mousemove="handleMouseMove"
          >
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" stroke-width="1"/>
              </pattern>
            </defs>
            <rect width="800" height="400" fill="url(#grid)" />
            
            <rect x="10" y="10" width="780" height="380" fill="none" stroke="#ef4444" stroke-width="1" stroke-dasharray="6,4" opacity="0.3"/>
            
            <path :d="smoothPathD" stroke="#3b82f6" stroke-width="3" fill="none" stroke-linecap="round" style="pointer-events: none;" />
            
            <circle 
              v-for="(p, i) in points" 
              :key="i" 
              :cx="p.x" 
              :cy="p.y" 
              r="6" 
              fill="#1e293b" 
              stroke="#fff" 
              stroke-width="2" 
              class="control-point"
              @mousedown.stop="handleMouseDown(i)"
            />
            
            <g v-if="hasPositionData" style="transition: all 0.2s linear; pointer-events: none;">
              <circle :cx="robotVisualPos.x" :cy="robotVisualPos.y" r="8" fill="#10b981" stroke="#fff" stroke-width="2" />
              <circle :cx="robotVisualPos.x" :cy="robotVisualPos.y" r="14" fill="#10b981" opacity="0.2">
                <animate attributeName="r" values="10;16;10" dur="2s" repeatCount="indefinite" />
              </circle>
            </g>
          </svg>
          <div class="canvas-hint" v-if="points.length === 0">点击画布规划路径，拖动圆点调整</div>
        </div>

        <div v-show="activeTab === 'camera'" class="camera-fullscreen">
          <img :src="videoFeedUrl" class="video-img" v-if="camOk" @error="camOk = false" />
          <div class="video-placeholder" v-else>
            <div class="no-signal">NO VIDEO SIGNAL FROM SDK</div>
            <p>请确保后端 OpenCV 模块已启动且摄像头连接正常</p>
          </div>
        </div>
      </div>
    </section>

    <aside class="control-column">
      <div class="panel side-card">
        <div class="card-title">实时遥测 / TELEMETRY</div>
        <div class="telemetry-grid">
          <div class="t-item">
            <label>X-AXIS (m)</label>
            <span class="val mono">{{ robotWorldPos.x.toFixed(3) }}</span>
          </div>
          <div class="t-item">
            <label>Y-AXIS (m)</label>
            <span class="val mono">{{ robotWorldPos.y.toFixed(3) }}</span>
          </div>
          <div class="t-item">
            <label>Z-AXIS (m)</label>
            <span class="val mono">{{ robotWorldPos.z.toFixed(3) }}</span>
          </div>
          <div class="t-item">
            <label>STATUS</label>
            <span class="val status-pill" :class="sdkStatus">{{ sdkStatus.toUpperCase() }}</span>
          </div>
        </div>
        
        <div class="progress-info" style="margin-top: 10px; padding: 10px; background: #f5f7fa; border-radius: 4px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: bold; color: #606266;">任务进度</span>
            <span style="font-size: 18px; color: #409eff; font-weight: bold;">
              {{ Math.floor(progress || 0) }}%
            </span>
          </div>
        </div>
      </div>

      <div class="panel side-card actions">
        <div class="card-title">指令中心 / COMMAND</div>
        <button class="btn-execute" @click="handleExecute" :disabled="points.length < 2 || isRunning">
          <span class="icon">{{ isRunning ? '⚙️' : '▶' }}</span>
          {{ isRunning ? '任务执行中...' : '开始执行轨迹' }}
        </button>
        
        <div class="btn-row">
          <button class="btn-tool" @click="undoPoint" :disabled="points.length === 0 || isRunning">
            撤回一步 (Undo)
          </button>
          <button class="btn-tool danger" @click="handleStop">
            紧急停止 (E-Stop)
          </button>
        </div>
        <button class="btn-tool" @click="points = []" :disabled="isRunning">清除所有规划</button>
      </div>

      <div class="panel side-card terminal-card">
        <div class="card-title">系统日志 / LOGS</div>
        <div class="terminal-body">
          <div class="log-entry">
            <span class="time">[{{ currentTime }}]</span>
            <span class="msg">{{ systemMsg }}</span>
          </div>
          <div class="log-entry error" v-if="errorMsg">
            <span class="time">ERROR</span>
            <span class="msg">{{ errorMsg }}</span>
          </div>
        </div>
      </div>
    </aside>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { shotApi } from '@/api/shot'
// 导入 TS 接口定义，确保类型检查通过
import type { Point } from '@/types/sdk' 

// --- 基础状态 ---
const activeTab = ref('canvas')

// 【关键修复】显式声明 Point[] 类型，解决 "缺少属性 z" 的报错
const points = ref<Point[]>([]) 

const sdkStatus = ref('idle')
const progress = ref(0)
const systemMsg = ref('SDK 系统已连接，等待指令...')
const errorMsg = ref('')
const currentTime = ref('')
const camOk = ref(true)
const videoFeedUrl = ref('/api/v1/video_feed')

const robotWorldPos = ref({ x: 0, y: 0, z: 0 })
const robotVisualPos = ref({ x: 0, y: 0 })
const hasPositionData = ref(false)

const isRunning = computed(() => sdkStatus.value === 'running')
const draggingIndex = ref(-1) // 当前正在拖动的点位索引

// --- 核心算法：曲线规划 (Catmull-Rom 插值) ---
const smoothPathD = computed(() => {
  if (points.value.length < 2) return ''
  let d = `M ${points.value[0].x} ${points.value[0].y}`
  if (points.value.length === 2) {
    return d + ` L ${points.value[1].x} ${points.value[1].y}`
  }
  for (let i = 0; i < points.value.length - 1; i++) {
    const p0 = points.value[i === 0 ? i : i - 1]
    const p1 = points.value[i]
    const p2 = points.value[i + 1]
    const p3 = points.value[i + 2 >= points.value.length ? i + 1 : i + 2]
    const cp1x = p1.x + (p2.x - p0.x) / 6
    const cp1y = p1.y + (p2.y - p0.y) / 6
    const cp2x = p2.x - (p3.x - p1.x) / 6
    const cp2y = p2.y - (p3.y - p1.y) / 6
    d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`
  }
  return d
})

// --- 交互逻辑：点击添加 & 拖动修改 ---
const handleCanvasClick = (e: MouseEvent) => {
  if (isRunning.value) return
  // 如果正在拖动，不触发添加点逻辑
  if (draggingIndex.value !== -1) return 

  const svg = document.getElementById('trajectory-canvas') as any
  const rect = svg.getBoundingClientRect()
  
  // 【关键修复】添加点时补全 z 属性，防止 TS 报错
  points.value.push({
    x: Math.max(0, Math.min(800, e.clientX - rect.left)),
    y: Math.max(0, Math.min(400, e.clientY - rect.top)),
    z: 0 // 默认为 0
  })
}

// 鼠标按下：开始拖动
const handleMouseDown = (index: number) => {
  if (isRunning.value) return
  draggingIndex.value = index
}

// 鼠标移动：更新点位
const handleMouseMove = (e: MouseEvent) => {
  if (draggingIndex.value === -1 || isRunning.value) return
  
  const svg = document.getElementById('trajectory-canvas') as any
  const rect = svg.getBoundingClientRect()
  
  const newX = Math.max(0, Math.min(800, e.clientX - rect.left))
  const newY = Math.max(0, Math.min(400, e.clientY - rect.top))
  
  // 更新当前拖动的点
  points.value[draggingIndex.value].x = newX
  points.value[draggingIndex.value].y = newY
}

// 鼠标松开：结束拖动
const handleMouseUp = () => {
  draggingIndex.value = -1
}

const undoPoint = () => {
  points.value.pop()
}

// 执行任务
const handleExecute = async () => {
  if (points.value.length < 2) return
  try {
    systemMsg.value = '正在解析轨迹并上传至机器人...'
    const res = await shotApi.startPath(points.value, 10)
    if (res.data.code === 200) {
      systemMsg.value = '任务启动成功，机器人正在执行轨迹。'
    } else {
      errorMsg.value = res.data.msg
    }
  } catch (e) {
    errorMsg.value = '通信异常：无法连接至 SDK 服务器'
  }
}

const handleStop = async () => {
  await shotApi.stop()
  systemMsg.value = '紧急停止指令已下发！'
}

// --- 状态轮询 ---
const pollStatus = async () => {
  try {
    const res = await shotApi.getStatus()
    if (res.data.code === 200 && res.data.data) {
      const data = res.data.data
      sdkStatus.value = data.status
      progress.value = data.progress ?? 0
      systemMsg.value = data.current_operation || '系统空闲'
      errorMsg.value = data.error_message || ''
      if (data.current_pos) {
        const [x, y, z] = data.current_pos
        robotWorldPos.value = { x, y, z }
        robotVisualPos.value = { x: x * 100 + 400, y: y * 100 + 200 }
        hasPositionData.value = true
      }
    }
  } catch (e) { /* 静默失败 */ }
}

let timer: any
onMounted(() => {
  pollStatus()
  timer = setInterval(pollStatus, 200)
  setInterval(() => currentTime.value = new Date().toLocaleTimeString(), 1000)
})
onUnmounted(() => clearInterval(timer))
</script>

<style scoped>
/* 【布局修复】
  1. gap: 10px -> 缩小左右间隙
  2. visual-panel 设为 flex: 1，control-column 设为固定宽 280px，
     这样左侧会自动占据剩余的大部分空间，实现“工作空间拉大”
*/
.dashboard-grid { 
  display: flex; 
  height: 100%; 
  gap: 10px; /* 间隙缩小 */
  overflow: hidden; 
}

/* 左侧可视化面板 (自适应变宽) */
.visual-panel { 
  flex: 1; 
  border: 1px solid #e2e8f0; 
  background: white; 
  border-radius: 12px; 
  display: flex; 
  flex-direction: column; 
  overflow: hidden; 
}

/* 右侧控制列 (固定宽度，适当改窄以留空间给左侧) */
.control-column { 
  width: 280px; 
  display: flex; 
  flex-direction: column; 
  gap: 16px; 
  flex-shrink: 0; 
}

/* 面板内部样式 */
.panel-header { height: 50px; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; padding: 0 20px; }
.tabs { display: flex; height: 100%; }
.tab { border: none; background: none; padding: 0 20px; font-size: 13px; font-weight: 600; color: #64748b; cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.2s; }
.tab.active { color: #0f172a; border-bottom-color: #3b82f6; }

.panel-tools { display: flex; gap: 10px; align-items: center; font-size: 12px; }
.tool-hint { color: #94a3b8; font-size: 11px; }

.visual-content { flex: 1; background: #f8fafc; position: relative; display: flex; align-items: center; justify-content: center; }
.canvas-wrapper { 
  width: 100%; /* 自适应宽度 */
  height: 100%; 
  max-width: 800px;
  max-height: 400px;
  background: white; 
  border: 1px solid #cbd5e1; 
  box-shadow: 0 4px 12px rgba(0,0,0,0.05); 
  cursor: crosshair; 
}
.canvas-wrapper.locked { cursor: not-allowed; opacity: 0.8; filter: grayscale(0.5); }
.canvas-hint { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: #94a3b8; font-size: 14px; font-weight: 600; pointer-events: none; }

/* 拖拽点的样式 */
.control-point { cursor: grab; transition: r 0.1s; }
.control-point:hover { r: 8; fill: #3b82f6; }
.control-point:active { cursor: grabbing; }

.camera-fullscreen { width: 100%; height: 100%; background: black; display: flex; align-items: center; justify-content: center; }
.video-img { max-width: 100%; max-height: 100%; }
.no-signal { color: #ef4444; font-weight: bold; font-family: monospace; }

.side-card { padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; }
.card-title { font-size: 11px; font-weight: 800; color: #94a3b8; letter-spacing: 1px; margin-bottom: 16px; text-transform: uppercase; }

.telemetry-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
.t-item { background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px; display: flex; flex-direction: column; }
.t-item label { font-size: 9px; font-weight: 700; color: #64748b; margin-bottom: 4px; }
.t-item .val { font-size: 15px; font-weight: 700; color: #0f172a; font-family: 'JetBrains Mono', monospace; }

.status-pill { padding: 2px 6px; border-radius: 4px; font-size: 10px; }
.status-pill.ready { background: #dcfce7; color: #166534; }
.status-pill.running { background: #fef3c7; color: #92400e; }

/* 按钮样式 */
.btn-execute { height: 56px; background: #0f172a; color: white; border: none; border-radius: 8px; font-weight: 700; width: 100%; cursor: pointer; transition: all 0.2s; margin-bottom: 12px; font-size: 14px; }
.btn-execute:hover:not(:disabled) { background: #1e293b; transform: translateY(-1px); }
.btn-execute:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-row { display: flex; gap: 10px; margin-bottom: 10px; }
.btn-tool { flex: 1; height: 40px; background: white; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; }
.btn-tool.danger { color: #ef4444; border-color: #fee2e2; }
.btn-tool.danger:hover { background: #fef2f2; }

/* 日志区 */
.terminal-body { background: #0f172a; padding: 12px; border-radius: 8px; font-family: 'JetBrains Mono', monospace; font-size: 11px; height: 100px; overflow-y: auto; color: #e2e8f0; }
.log-entry { margin-bottom: 4px; display: flex; gap: 8px; }
.log-entry .time { color: #64748b; flex-shrink: 0; }
.log-entry.error .msg { color: #fca5a5; }
</style>