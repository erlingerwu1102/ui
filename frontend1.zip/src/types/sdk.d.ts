// src/types/sdk.d.ts

export interface SdkResponse<T = any> {
  code: number;
  msg: string;
  data: T;
  error?: any;
}

export interface RobotStatus {
  // SDK 核心字段
  status: 'idle' | 'running' | 'error' | 'stopped';
  current_operation: string;
  error_message: string;
  current_pos: [number, number, number]; // [x, y, z]
  current_angle: number;
  coordinate_system: string;
  collision_detection_enabled: boolean;
  torque_feedforward_enabled: boolean;

  // --- 修复报错的关键点 ---
  // 将代码中用到的、但后端可能未返回的字段设为可选
  msg?: string;       // 解决 Property 'msg' does not exist
  progress?: number;  // 解决 'unknown' not assignable to 'number'
}

export interface Point {
  x: number;
  y: number;
  z: number;
}