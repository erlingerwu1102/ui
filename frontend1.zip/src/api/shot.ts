import axios from 'axios'
import type { SdkResponse, RobotStatus, Point } from '@/types/sdk'

// 创建 axios 实例
const api = axios.create({
  baseURL: '/api/v1',
  timeout: 5000,
  headers: {
    'Content-Type': 'application/json',
    // 【关键修复】添加 API Key 解决 401 错误
    // 如果后端 routes.py 验证了 Key，前端必须在这里提供
    'X-API-Key': 'default_key' 
  }
})

export const shotApi = {
  /**
   * 获取机器人实时状态
   */
  getStatus: () => {
    return api.get<SdkResponse<RobotStatus>>('/status')
  },

  /**
   * 下发轨迹指令 (前端坐标修复版)
   */
  startPath: (path: Point[], duration: number) => {
    if (!path || path.length === 0) return Promise.reject('Path empty');

    // --- 坐标换算逻辑 ---
    // 假设画布坐标是像素 (如 3000), 机械臂需要米 (如 0.3)
    const SCALE = 0.0001; 
    const HOME_X = 0.25; // 安全起始位
    const HOME_Y = 0.0;
    const HOME_Z = 0.2;

    const startPt = path[0] as any;

    const fixedPath = path.map(p => {
      const point = p as any;
      const origZ = point.z !== undefined ? point.z : 0;
      const startZ = startPt.z !== undefined ? startPt.z : 0;

      return {
        ...p,
        // 转换为相对于起点的偏移量 + 安全起始位，确保不超出工作空间
        x: (point.x - startPt.x) * SCALE + HOME_X,
        y: (point.y - startPt.y) * SCALE + HOME_Y,
        z: (origZ - startZ) * SCALE + HOME_Z
      };
    });
    // ------------------

    return api.post<SdkResponse>('/path', {
      path: fixedPath,
      duration
    })
  },

  /**
   * 紧急停止
   */
  stop: () => {
    // 确保路由与后端 bp.route('/emergency/stop') 一致
    return api.post<SdkResponse>('/emergency/stop')
  },
  
  /**
   * 碰撞检测配置
   */
  setCollisionDetection: (enabled: boolean) => {
    return api.post<SdkResponse>('/config/collision', {
      sensitivity: 50,
      enabled: enabled
    })
  }
}