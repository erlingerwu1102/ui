<template>
  <router-view />
</template>

<script setup lang="ts">
/**
 * App.vue 保持简洁
 * 复杂的布局和逻辑已经迁移到了 src/layouts/MainLayout.vue 
 * 和 src/views/TrajectoryView.vue 中
 */
</script>

<style>
/* 全局样式重置 */
#app {
  width: 100vw;
  height: 100vh;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

body {
  margin: 0;
  padding: 0;
}
</style>