import { ref, reactive } from 'vue'

// 共享状态 (Singleton Pattern)
const isPlaying = ref(false)
const progress = ref(0)
const currentTime = ref(0)
const robotPos = reactive({ x: 0, y: 0, z: 0 }) // 使用 reactive 确保深度监听
const joints = ref([0, 0, 0, 0, 0, 0])

export function useTrajectoryRunner() {
  
  // 核心算法：根据进度(0-100)计算当前 XYZ
  const updateRobotState = (points: any[], prog: number) => {
    // 1. 模拟关节动画 (正弦波呼吸效果)
    joints.value = joints.value.map((v, i) => v + Math.sin(Date.now() / 200 + i) * 0.5)

    // 2. XYZ 线性插值
    if (!points || points.length === 0) return
    if (points.length === 1) {
      Object.assign(robotPos, points[0])
      return
    }

    const totalSegments = points.length - 1
    const tTotal = prog / 100
    // 找到当前处于哪一段
    let idx = Math.floor(tTotal * totalSegments)
    if (idx >= totalSegments) idx = totalSegments - 1
    
    // 段内进度 (0.0 - 1.0)
    const segmentLen = 1 / totalSegments
    const tLocal = (tTotal - (idx * segmentLen)) / segmentLen

    const p1 = points[idx]
    const p2 = points[idx + 1]

    if (p1 && p2) {
      robotPos.x = p1.x + (p2.x - p1.x) * tLocal
      robotPos.y = p1.y + (p2.y - p1.y) * tLocal
      robotPos.z = p1.z + (p2.z - p1.z) * tLocal
    }
  }

  return {
    isPlaying,
    progress,
    currentTime,
    robotPos, // 暴露给 SystemPanel 使用
    joints,   // 暴露给 OperationPanel 使用
    updateRobotState
  }
}