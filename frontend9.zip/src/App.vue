<template>
  <router-view />
</template>

<script setup lang="ts">
/**
 * App.vue 保持简洁
 * 复杂的布局和逻辑已经迁移到了 src/layouts/MainLayout.vue 
 * 和 src/views/TrajectoryView.vue 中
 */
</script>

<style>
/*
*App.vue 保持简洁
*复杂的布局和逻辑已经迁移到了src/index.css中
*/ 
</style>