//全局状态
let points=[];
let currentMode='custom';
let isRunning=false;
let animationId=null;
const canvas=document.getElementById('trajectory-canvas');
const stopBtn=document.getElementById('stop-btn');
const modeButtons=document.querySelectorAll('.preset-buttons button');
//DOM更新函数
function updateStatus(){
    document.getElementById('current-mode').textContent=currentMode;
    document.getElementById('point-count').textContent=points.length;
    document.getElementById('run-status').textContent=isRunnings?'运行中':'空闲';
}
//清空画布
function clearCanvas(){
    while(canvas.firstChild){
        if(canvas.firstChild.tagName !== 'rect'){
            canvas.removeChild(canvas.firstChild);
        }else break;
    }
}
//绘制轨迹和控制点
function drawTrajectory(){
    clearCanvas();
    if(points.length<2) return;
    //绘制路径
    const pathD=['M',points[0].x,points[0].y];
    for(let i=1;i<points.length;i++){
        pathD.push('L',point[i].x,point[i].y);
    }
    const path=document.createElementNS('http://www.w3.org/2000/svg','path');
    path.setAttribute('d',pathD.join(''));
    path.setAttribute('stroke','#3498db');
    path.setAttribute('stroke-width','2');
    path.setAttribute('fill','none');
    canvas.appendChild(path);
    //绘制控制点（可拖拽）
    points.foeEach((pt,i)=>{
      const circle=const path=document.createElementNS('http://www.w3.org/2000/svg','circle');
      circle.setAttribute('cx',pt.x);
      circle.setAttribute('cx',pt.y);
      circle.setAttribute('r',6);
      circle.setAttribute('fill','#e74c3c');
      circle.setAttribute('data-index',i);
      circle.style.cursor='move';
      //拖拽逻辑
      let isDragging=false;
      circle.addEventListener('mousedown',(e)=>{
        isDragging=true;
        e.preventDefault();
      });
      circle.addEventListener('mousemove',(e)=>{
        if(!isDragging) return;
        const rect=canvas.getBoundingCilentRect();
        const x=e.clientX-rect.left;
        const y=e.clientY-rect.top;
        points[i]={x,y};
        drawTrajectory();
        updateStatus();
      });
      window.addEventListener('mouseup',()=>{
        isDragging=false;
      });
      canvas.appendChild(circle);
      });
    }
    //点击画布添加点
    canvas.addEventListener('click',(e)=>{
        if(isRunning)return;
        const rect=canvas.getBoundingClientRect();
            const x=e.clientX-rect.left;
            const y=e.clientY-rect.top;
            points.push({x,y});
            drawTrajectory();
            updateStatus();
    });
        //模式切换
        modeButtons.forEach(btn=>{
            btn.addEventListener('click',()=>{
                currentMode=btn.dataset.mode;
                if(currentMode!=='custom'){
                    //预设轨迹
                    points=generatePresetPath(currentMode);
                    drawTrajectory();
                }
                updateStatus();
            });
        });
        //预设轨迹生成
        function generatePresetPath(mode){
            const w=800,h=400;
            switch(mode){
                case 'orbit':
                    return [
                        {x:w*0.5,y:h*0.2},
                        {x:w*0.8,y:h*0.5},
                        {x:w*0.5,y:h*0.8},
                        {x:w*0.2,y:h*0.5},
                        {x:w*0.5,y:h*0.2}
                    ];
                case'dolly':
                return[
                    {x:w*0.1,y:h*0.5},
                    {x:w*0.9,y:h*0.5}
                ];
                case 'pan':
                    return[
                        {x:w*0.5,y:h*0.1},
                        {x:w*0.5,y:h*0.9}
                    ];
                default:
                    return [];
            }
        }
        //模拟运镜动画
        function simulateRun(){
            if(points.length<2){
                alert('请先设置轨迹！');
                return;
            }
            isRunning=true;
            updateStatus();
            const progressBar=document.getElementById('progress-bar');
            let progress=0;
            const totalSteps=100;
            function step(){
                if(progress>=totalSteps||!isRunning){
                    isRunning=false;
                    progressBar.value=0;
                    updateStatus();
                    return;
                }
                progress++;
                progressBar.value=progress;
                animationId=requestAnimationFrame(step);
            }
            step();
        }
        //紧急停止
        stopBtn.addEventListener('click',()=>{
            isRunning=false;
            if(animationId)cancelAnimationFrame(animationId);
            updateStatus();
            document.getElementById('progress-bar').value=0;
            alert('运镜已紧急停止！');
        });
        //启动默认模拟（可选：点击任意预设或自定义后按空格启动）
        document.addEventListener('keydown',(e)=>{
            if(e.code==='Space'&&!isRunning){
                simulateRun();
            }
        });
//初始化
updateStatus();