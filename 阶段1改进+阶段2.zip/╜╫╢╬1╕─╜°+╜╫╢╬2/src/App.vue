<template>
    <div id="app">
      <h1 style="text-align:center;margin-top:40px;">基础运镜控制面板</h1>
      <ShotControl />
    </div>
</template>
<script setup lang="ts">
import ShotControl from './components/ShotControl.vue'
</script>
<style>
#app {
  font-family:Avenir,Helvetica,Arial,sans-serif;
  text-align:center;
  max-width:800px;
  margin:0 auto;
  color:#2c3e50;
  padding:20px;
}
</style>