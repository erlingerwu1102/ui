<template>
  <div class="shot-control">
    <h2>基础运镜控制面板</h2>
  <!--加载状态-->
  <div v-if="loading" class="feedback loading">
    <LoadingSpinner/>
    <span>操作中...</span>
  </div>
  <!--错误提示-->
  <div v-if="errorMessage" class="feedback error">
     {{ errorMessage }}
  </div>
  <!--成功提示-->
  <div v-if="successMessage" class="feedback success">
    {{ successMessage }}
  </div>
</div>
   <el-card class="box-card">
        <!--参数输入区-->
        <div class="section">
          <h3>参数设置</h3><!--参数设置区-->
            <el-form :model="form" label-width="100px" size="large">
                <el-form-item label="速度(m/s)">
                  <el-input-number v-model="form.speed":min="0.1" :max="10" :step="0.1" />
                </el-form-item>
                <el-form-item label="角度（°）">
                  <el-input-number v-model="form.angle":min="0" :max="360" :step="5" />
                </el-form-item>
                <el-form-item label="持续时间(s)">
                   <el-input-number v-model="form.duration":min="1" :max="60" :step="1" />
                </el-form-item>
            </el-form>
        </div>
            
        <!--控制按钮区-->
        <div class="section">
            <h3>控制</h3><!--控制-->
            <div class="button group">
                <el-button
                  type="primary"
                  :loading="loading"
                  @click="handleStart"
                  :disabled="status !=='ready'"
                >
                {{  loading ? '启动中...' : '开始运镜' }}
            </el-button>
            <el-button
              type="warning"
              @click="handlePause"
              :disabled="status !== 'running'"
              >
              <!--暂停-->

            </el-button>
            <el-button
              type="danger"
              @click="handleStop"
              :disabled="status === 'ready'"
              >
              <!--停止-->

            </el-button>
            </div>
        </div>
        <!--状态显示区-->
        <div class="section status-section">
            <p><strong>当前状态：</strong>{{ diaplayStatus }}</p>
            <p><strong>当前速度：</strong>{{ lacalSpeed }}</p>
            <el-tag
              :type="statusTagType"
              size="large"
              effect="dark"
              class="status-tag"
            >   
              {{  statusText }}
            </el-tag>
        </div>
    </el-card>
</template>
<script setup lang="ts">
import { ref, computed,onMounted} from 'vue'//报错区域
import { ElMessage } from 'element-plus'//报错区域
import { shotApi, ShotParams,getCameraStatus } from '@/api/shot'//报错区域
//表单数据
const form =ref<ShotParams>({
  speed:1.0,
  angle:45,
  duration:10
})
//状态管理
const status =ref<'ready'|'running'|'paused'|'stopped'>('ready')
const lacalSpeed =ref<number>(5)
const loading=ref<boolean>(false)
const errorMessage =ref<string|null>(null)
const successMessage =ref<string|null>(null)
//状态文本映射,显示友好状态文本
const statusTextMap = {
  ready:'就绪',
  running:'运行中',
  paused:'已暂停',
  stopped:'已停止'
}
const diaplayStatus=computed(()=>{
return statusTextMap[status.value]||status.value
})
const statusText =computed(() => {
  const val=status.value
  return statusTextMap[val] ??''//报错区域
})
const statusTagType =computed(() =>{
  if(status.value === 'ready') return 'success'
  if(status.value === 'running') return 'info'
  if(status.value === 'paused') return 'warning'
  return 'danger'
})
//清除提示信息
const clearMessage =()=>{
  errorMessage.value=null;
  successMessage.value=null;
}
//开始
const handleStart = async () =>{
  clearMessage()
  loading.value = true
  try{
    await shotApi.start(form.value)
    status.value ='running'
    ElMessage.success('运镜已启动!')
    setTimeout(()=>(successMessage.value=null),2000)
  }catch(error){
    ElMessage.error('启动失败：'+(error as Error).message)
  }finally{
    loading.value=false
  }
}
//暂停（本地模拟）
const handlePause = () =>{
  status.value='paused'
  ElMessage.warnings('运镜已暂停')
}
//停止
const handleStop = async () =>{
  try{
    await shotApi.stop()
    status.value='stopped'
    ElMessage.info('运镜已停止')
    //1秒后自动回到就绪状态
    setTimeout(() =>{
      status.value = 'ready'
    },1000)
  } catch(err:any){
    const msg=err.response?.data?.message||err.message||'未知错误'
    ElMessage.error('停止失败')
    setTimeout(()=>(errorMessage.value=null),3000)
  }finally{
    loading.value=false
  }
}
//初始化：获取当前状态
onMounted(async ()=>{
  loading.value=true
  try{
    const res=await getCameraStatus()
    status.value=res.data.statuslocalSpeed.value=res.data.speed
  }catch(err:any){
    errorMessage.value='初始化失败：无法获取相机状态'
    console.error(err)
  }finally{
    loading.value=false
  }
})
</script>
<style scoped>
.shot-control{
  max-width:500px;
  margin:0 auto;
  padding:20px;
  border:1px soild #eaeaea;
  border-radius:8px;
  font-family:Arial, Helvetica, sans-serif;
}
.section {
  margin-bottom: 24px;
}
.input-section input{
  margin-left:8px;
  padding:4px;
  width:80px;
}
.button-section button{
  margin-right:10px;
  padding:8px 16px;
  border:none;
  border-radius:4px;
  background-color:#409eff;
  color:white;
  cursor:pointer;
}
.button-section button:disabled{
  background-color:#ccc;
  cursor:not-allowed;
}
.feedback{
  padding:8px 12px;
  margin:10px 0;
  border-radius:4px;
  display:flex;
  align-items:center;
  gap:8px;
}
.feedback.loading{
  background-color:#e3f2fd;
  color:#1976d2;
}
.feedback.success{
  background-color:#d4edda;
  color:#155724;
}
feedback.error{
  background-color:#f8d7da;
  color:#721c24;
}
.button-group {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.status-tag {
  font-size: 18px;
  padding: 12px 24px;
}
</style>