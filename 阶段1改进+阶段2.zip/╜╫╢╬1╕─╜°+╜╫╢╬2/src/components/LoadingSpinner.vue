<!--创建动画加载组件-->
<template>
    <div class=""loading-spinner>
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
    </div>
</template>
<style scoped>
.loading-spinner{
    display:inline-block;
    width:24px;
    height:24px;
    position:relative;
}
.bounce1,.bounce2,.bounce3{
    width:100%;
    height:100%;
    background-color:#409eff;
    border-radius:50%;
    opacity:0.6;
    position:absolute;
    top:0;
    left:0;
    animation:bounce 1.4s infinite ease-in-out both;
}
.bounce1{animation-delay:-0.32s;}
.bounce2{animation-delay:-0.16s;}
@keyframes bounce{
    0%,80%,100%{
      transform:scale(0);
      opacity:0.4;  
    }
    40%{
        transform:scale(1);
        opacity:1;
    }
}
</style>