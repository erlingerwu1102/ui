import axios from 'axios'//报错1
//Mock API address(之后替换为真实的后端地址)
const API_BASE = 'https://660d4e0f6dd46be03334e9d7.mockapi.io'
export interface ShotParams{
    speed:number;//填写真实数据
    angle:number;//填写真实数据
    duration:number;//填写真实数据
}
export const shotApi={
    async start(params:ShotParams){
        try{
            const res=await axios.post(`${API_BASE}/shots`,params)
            return res.data
        }catch(error){
            console.error('启动失败：',error)
            throw error
        } 
    },
    async stop(){
        try{
            //模拟停止操作（与真实后端相连接）
            await new Promise(resolve=>setTimeout(resolve,500))
            return{success:true}
        }catch(error){
            console.error('停止失败:',error)
            throw error
        }
    }
}