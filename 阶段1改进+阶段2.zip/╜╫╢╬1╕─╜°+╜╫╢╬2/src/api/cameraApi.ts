//API封装文件
import axios from 'axios'
const api = axios.create({
    baseURL:'/api',//根据实际接口调整
    timeout:10000.
})
export const getCameraStatus = () =>{
    return api.get<{status:String;speed:number}>('/camera/status')
}
export const comntrolCamera=(action:'start'|'stop'|'reset')=>{
    return api.post('/camera/control',{action})
}