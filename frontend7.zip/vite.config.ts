// frontend/vite.config.ts
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  },
  server: {
    host: '0.0.0.0', // 允许局域网访问
    port: 5173,
    open: true,
    // 【关键配置】跨域代理
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000', // 后端地址 (注意端口必须与后端一致)
        changeOrigin: true, // 允许跨域
        secure: false       // 如果后端是 https 但没有证书，设为 false
      }
    }
  }
})