<template>
  <div class="panel-container custom-scroll">
    <div v-if="modelValue" class="group-box">
      <div class="box-header">TARGET DURATION</div>
      <div class="time-inputs">
        <div class="input-col">
          <input type="number" v-model.number="modelValue.h" min="0">
          <label>HR</label>
        </div>
        <span class="sep">:</span>
        <div class="input-col">
          <input type="number" v-model.number="modelValue.m" min="0" max="59">
          <label>MIN</label>
        </div>
        <span class="sep">:</span>
        <div class="input-col">
          <input type="number" v-model.number="modelValue.s" min="1" max="59">
          <label>SEC</label>
        </div>
      </div>
      <div class="total-bar">
        <span>TOTAL</span>
        <span class="val">{{ totalSeconds }}s</span>
      </div>
    </div>

    <div class="group-box">
      <div class="box-header">MOTION PARAMETERS</div>
      
      <div class="param-row">
        <label>Velocity</label>
        <div class="control-flex">
          <input type="range" v-model.number="params.speed" min="1" max="100" class="j-slider">
          <span class="val-text">{{ params.speed }}%</span>
        </div>
      </div>

      <div class="param-row dwell-row">
        <label>Cycle Dwell</label>
        <div class="input-wrap">
          <input type="number" v-model.number="params.dwellTime" min="0" step="0.5" class="num-input">
          <span class="unit">S</span>
        </div>
      </div>
      
      <div class="info-row">
        <span>Waypoints</span>
        <span class="val-highlight">{{ pointCount }}</span>
      </div>
    </div>

    <div class="group-box flex-fill">
      <div class="box-header">JOINT OVERRIDE</div>
      <div class="joint-list custom-scroll">
        <div v-for="(val, i) in joints" :key="i" class="joint-item">
          <div class="j-row-top">
            <span>AXIS {{ i + 1 }}</span>
            <span class="j-val">{{ val.toFixed(1) }}°</span>
          </div>
          <input type="range" v-model.number="joints[i]" min="-180" max="180" step="0.1" class="j-slider">
        </div>
      </div>
      <button class="reset-btn" @click="$emit('reset')">RESET JOINTS</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useTrajectoryRunner } from '@/composables/useTrajectoryRunner'

// 修复 TypeScript 类型不匹配
const props = defineProps<{
  modelValue?: { h: number, m: number, s: number }, // 设为可选，修复“缺少modelValue”报错
  params: { speed: number, accel: number, dwellTime: number },
  pointCount: number // 接收父组件传递的 pointCount
}>()

const emit = defineEmits(['update:modelValue', 'reset'])
const { joints } = useTrajectoryRunner()

const totalSeconds = computed(() => {
  if (!props.modelValue) return 0
  return (props.modelValue.h * 3600) + (props.modelValue.m * 60) + props.modelValue.s
})
</script>

<style scoped>
/* 皮肤自适应核心：强制对比度 */
.panel-container { 
  display: flex; flex-direction: column; gap: 12px; height: 100%; 
  overflow-y: auto; padding-right: 4px;
}

.group-box {
  background: var(--bg-panel); /* 随皮肤变：暗色下为深蓝，亮色下为浅灰 */
  border: 1px solid var(--border-color);
  border-radius: 6px; padding: 12px; display: flex; flex-direction: column;
}
.flex-fill { flex: 1; min-height: 0; }

.box-header { 
  font-size: 10px; font-weight: 800; color: var(--text-secondary); 
  margin-bottom: 12px; border-bottom: 1px solid var(--border-color);
  padding-bottom: 4px;
}

/* 输入框核心修复：解决白底白字 */
input[type="number"], .num-input {
  background: var(--input-bg) !important; /* 强制背景跟随变量 */
  color: var(--input-text) !important;   /* 强制文字跟随变量 */
  border: 1px solid var(--border-color);
  border-radius: 4px; padding: 6px; font-family: monospace; outline: none;
}

.time-inputs { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
.input-col { display: flex; flex-direction: column; align-items: center; flex: 1; }
.input-col input { width: 100%; text-align: center; font-size: 14px; font-weight: bold; }
.input-col label { font-size: 8px; color: var(--text-secondary); margin-top: 4px; }
.sep { margin-bottom: 15px; font-weight: bold; color: var(--text-secondary); }

.param-row { display: flex; flex-direction: column; gap: 6px; margin-bottom: 12px; }
.param-row label { font-size: 10px; font-weight: bold; color: var(--text-secondary); }
.control-flex { display: flex; align-items: center; gap: 10px; }
.val-text { font-size: 10px; font-family: monospace; color: var(--accent-color); width: 35px; }

/* Cycle Dwell 特殊布局 */
.dwell-row { flex-direction: row; justify-content: space-between; align-items: center; }
.input-wrap { display: flex; align-items: center; gap: 4px; }
.num-input { width: 50px; text-align: right; }
.unit { font-size: 9px; color: var(--text-secondary); }

.total-bar { 
  background: rgba(59, 130, 246, 0.1); border-radius: 4px; padding: 8px; 
  display: flex; justify-content: space-between; font-size: 10px; 
}
.total-bar .val { color: var(--accent-color); font-weight: bold; }

.info-row { 
  display: flex; justify-content: space-between; font-size: 10px; 
  padding-top: 8px; border-top: 1px dashed var(--border-color); 
}
.val-highlight { color: var(--accent-color); font-weight: bold; }

/* 关节列表 */
.joint-list { overflow-y: auto; padding-right: 4px; flex: 1; }
.joint-item { margin-bottom: 12px; }
.j-row-top { display: flex; justify-content: space-between; font-size: 9px; color: var(--text-secondary); margin-bottom: 4px; }
.j-val { color: var(--input-text); font-family: monospace; }
.j-slider { width: 100%; height: 4px; accent-color: var(--accent-color); cursor: pointer; }

.reset-btn { 
  width: 100%; padding: 10px; background: transparent; 
  border: 1px dashed var(--border-color); color: var(--text-secondary);
  font-size: 10px; font-weight: bold; cursor: pointer; border-radius: 4px;
  transition: all 0.2s; margin-top: 8px;
}
.reset-btn:hover { border-color: var(--accent-color); color: var(--accent-color); }

.custom-scroll::-webkit-scrollbar { width: 4px; }
.custom-scroll::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 2px; }
</style>