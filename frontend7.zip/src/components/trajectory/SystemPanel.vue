<template>
  <div class="panel-container">
    <div class="group-box">
      <div class="box-header">
        <span class="icon">📊</span>
        <span class="title">REAL-TIME TELEMETRY</span>
      </div>
      <div class="telemetry-grid">
        <div class="t-item">
          <span class="label">POS X</span>
          <span class="value">{{ robotPos.x.toFixed(3) }}</span>
        </div>
        <div class="t-item">
          <span class="label">POS Y</span>
          <span class="value">{{ robotPos.y.toFixed(3) }}</span>
        </div>
        <div class="t-item">
          <span class="label">POS Z</span>
          <span class="value">{{ robotPos.z.toFixed(3) }}</span>
        </div>
      </div>
    </div>

    <div class="group-box flex-fill">
      <div class="box-header">
        <span class="icon">💻</span>
        <span class="title">SYSTEM TERMINAL</span>
      </div>
      <div class="terminal custom-scroll" ref="logBox">
        <div v-for="(log, i) in logs" :key="i" class="log-entry">
          <span class="ts">[{{ log.time }}]</span>
          <span :class="['content', log.type]">{{ log.msg }}</span>
        </div>
      </div>
    </div>

    <button class="estop-btn" @click="$emit('estop')">
       EMERGENCY STOP
    </button>
  </div>
</template>

<script setup lang="ts">
import { watch, ref, nextTick } from 'vue'
import { useTrajectoryRunner } from '@/composables/useTrajectoryRunner'

// 修复点：将 defineProps 赋值给 props 变量，否则下方 watch 无法读取 props
const props = defineProps<{ logs: any[] }>()
const emit = defineEmits(['estop'])

const { robotPos } = useTrajectoryRunner()
const logBox = ref<HTMLElement>()

// 自动滚动
watch(() => props.logs.length, () => {
  nextTick(() => {
    if (logBox.value) logBox.value.scrollTop = logBox.value.scrollHeight
  })
})
</script>

<style scoped>
.panel-container { display: flex; flex-direction: column; gap: 12px; height: 100%; }

.group-box {
  background: var(--bg-panel);
  border: 1px solid var(--border-color);
  border-radius: 6px;
  padding: 12px;
  display: flex; flex-direction: column;
}
.flex-fill { flex: 1; min-height: 0; }

.box-header { 
  display: flex; align-items: center; gap: 6px; margin-bottom: 12px; 
  border-bottom: 1px solid var(--border-color); padding-bottom: 8px;
}
.box-header .icon { font-size: 14px; }
.box-header .title { font-size: 10px; font-weight: 800; color: var(--text-secondary); }

/* 遥测数据网格 */
.telemetry-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }
.t-item { 
  background: var(--bg-input);
  border: 1px solid var(--border-color);
  border-radius: 4px; padding: 8px; text-align: center;
}
.t-item .label { display: block; font-size: 8px; color: var(--text-secondary); margin-bottom: 2px; }
.t-item .value { display: block; font-family: monospace; font-size: 12px; font-weight: bold; color: var(--accent-color); }

/* 终端日志 */
.terminal {
  flex: 1;
  background: var(--bg-terminal, #000);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  padding: 8px;
  overflow-y: auto;
  font-family: 'Consolas', monospace;
  font-size: 10px;
}

.log-entry { margin-bottom: 4px; line-height: 1.4; border-bottom: 1px solid rgba(128,128,128,0.1); padding-bottom: 2px; }
.ts { color: #64748b; margin-right: 6px; }
.content { color: var(--text-primary); }
.content.error { color: #ef4444; }
.content.success { color: #10b981; }
.content.warning { color: #f59e0b; }

.estop-btn {
  background: #ef4444; color: #fff; border: none; padding: 14px;
  font-weight: 900; border-radius: 6px; cursor: pointer; letter-spacing: 1px;
  box-shadow: 0 4px 6px rgba(239, 68, 68, 0.2); transition: all 0.2s;
}
.estop-btn:hover { background: #dc2626; transform: translateY(-1px); }

.custom-scroll::-webkit-scrollbar { width: 4px; }
.custom-scroll::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 2px; }
</style>