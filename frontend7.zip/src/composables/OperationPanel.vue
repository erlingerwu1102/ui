<template>
  <div class="panel-container custom-scroll">
    <div class="group-box">
      <div class="box-header">
        <span class="icon">⏱️</span>
        <span class="title">TARGET DURATION</span>
      </div>
      
      <div class="time-inputs">
        <div class="input-col">
          <input type="number" v-model.number="modelValue.h" min="0" placeholder="00">
          <label>HR</label>
        </div>
        <span class="sep">:</span>
        <div class="input-col">
          <input type="number" v-model.number="modelValue.m" min="0" max="59" placeholder="00">
          <label>MIN</label>
        </div>
        <span class="sep">:</span>
        <div class="input-col">
          <input type="number" v-model.number="modelValue.s" min="1" max="59" placeholder="10">
          <label>SEC</label>
        </div>
      </div>
      
      <div class="total-bar">
        <span>TOTAL SECONDS</span>
        <span class="val">{{ totalSeconds }}s</span>
      </div>
    </div>

    <div class="group-box flex-fill">
      <div class="box-header">
        <span class="icon">🦾</span>
        <span class="title">JOINT OVERRIDE</span>
      </div>
      <div class="joint-list custom-scroll">
        <div v-for="(val, i) in joints" :key="i" class="joint-item">
          <div class="j-row-top">
            <span class="j-name">AXIS {{ i + 1 }}</span>
            <span class="j-val">{{ val.toFixed(1) }}°</span>
          </div>
          <input 
            type="range" 
            v-model.number="joints[i]" 
            min="-180" max="180" 
            step="0.1"
            class="j-slider"
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useTrajectoryRunner } from '@/composables/useTrajectoryRunner'

const props = defineProps<{ modelValue: { h: number, m: number, s: number } }>()
const emit = defineEmits(['update:modelValue'])

const { joints } = useTrajectoryRunner()

const totalSeconds = computed(() => 
  (props.modelValue.h * 3600) + (props.modelValue.m * 60) + props.modelValue.s
)
</script>

<style scoped>
.panel-container { display: flex; flex-direction: column; gap: 12px; height: 100%; overflow-y: auto; padding-right: 4px; }

/* 框线风格优化：使用半透明边框，更细腻 */
.group-box {
  background: var(--bg-panel);
  border: 1px solid var(--border-color);
  border-radius: 6px;
  padding: 12px;
  display: flex; flex-direction: column;
}
.flex-fill { flex: 1; min-height: 0; }

.box-header { 
  display: flex; align-items: center; gap: 6px; margin-bottom: 12px; 
  border-bottom: 1px solid var(--border-color); padding-bottom: 8px;
}
.box-header .icon { font-size: 14px; }
.box-header .title { font-size: 10px; font-weight: 800; color: var(--text-secondary); letter-spacing: 0.5px; }

/* 时间输入框 */
.time-inputs { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
.input-col { display: flex; flex-direction: column; align-items: center; flex: 1; }
.input-col input {
  width: 100%; text-align: center; background: var(--bg-input); 
  border: 1px solid var(--border-color); color: var(--accent-color);
  font-family: 'Roboto Mono', monospace; font-size: 16px; font-weight: bold;
  padding: 8px; border-radius: 4px; outline: none; transition: border 0.2s;
}
.input-col input:focus { border-color: var(--accent-color); }
.input-col label { font-size: 8px; color: var(--text-secondary); margin-top: 4px; font-weight: 700; }
.sep { font-size: 16px; font-weight: bold; color: var(--text-secondary); margin-bottom: 16px; }

.total-bar { 
  background: rgba(59, 130, 246, 0.1); border-radius: 4px; padding: 8px; 
  display: flex; justify-content: space-between; align-items: center;
  font-size: 10px; color: var(--text-primary);
}
.total-bar .val { font-family: monospace; font-weight: bold; color: var(--accent-color); font-size: 12px; }

/* 关节滑块 */
.joint-list { overflow-y: auto; padding-right: 4px; }
.joint-item { margin-bottom: 12px; }
.j-row-top { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 9px; color: var(--text-secondary); }
.j-val { font-family: monospace; color: var(--text-primary); }
.j-slider { 
  width: 100%; height: 4px; border-radius: 2px;
  background: var(--bg-input); appearance: none; outline: none; cursor: pointer;
}
.j-slider::-webkit-slider-thumb {
  appearance: none; width: 12px; height: 12px; border-radius: 50%;
  background: var(--accent-color); border: 2px solid var(--bg-panel);
}

/* 滚动条 */
.custom-scroll::-webkit-scrollbar { width: 4px; }
.custom-scroll::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 2px; }
</style>